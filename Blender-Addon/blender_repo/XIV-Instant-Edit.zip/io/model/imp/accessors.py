import numpy as np

from numpy         import single, ubyte
from numpy.typing  import NDArray
            
from ..com.helpers import (byte_to_vector, normalise_vectors, calc_tangents_with_bitangent, quantise_flow,
                           zero_flow_bytes, ZERO_FLOW_COLOUR)
from ..com.space   import xiv_to_blend_space, tangent_to_world_space


def get_positions(streams: dict[int, NDArray]) -> NDArray:
    # Position is stored as HALF4 (x, y, z, w); w is unused padding. Blender's
    # foreach_set("co", ...) expects exactly 3 floats per vertex, so the 4th
    # column must be dropped here rather than left for the caller to flatten -
    # otherwise every vertex after the first reads increasingly misaligned
    # data (borrowing bytes from a neighbouring vertex), an error that grows
    # with vertex count and was invisible on typical gear but catastrophic on
    # an unusually dense mesh.
    #
    # The submesh streams are views into the mesh's shared stream arrays, and
    # submesh vertex ranges can overlap. Convert a copy so a vertex is never
    # converted more than once.
    return xiv_to_blend_space(streams[0]["position"].copy())[:, :3]

def get_shape_positions(streams: dict[int, NDArray], shape_vertices: NDArray, shape_indices: NDArray) -> NDArray:
    # Convert a private copy of the whole stream. The shared stream is left in
    # XIV space, so this does not depend on get_positions() having touched it.
    pos = xiv_to_blend_space(streams[0]["position"].copy())
    pos[shape_indices] = pos[shape_vertices]

    # Same HALF4 padding column as get_positions() - drop it before this
    # reaches a shape key's foreach_set("co", ...), which is also 3-wide.
    return pos[:, :3]

def get_normals(streams: dict[int, NDArray]) -> NDArray | None:
    return xiv_to_blend_space(normalise_vectors(streams[1]["normal"][:, :3]))

def get_uv0(streams: dict[int, NDArray]) -> list[NDArray]:
    uv_arrays = []
    
    uv0       = streams[1]["uv0"].copy()
    uv0[:, 1] = 1 - uv0[:, 1] 
    uv_arrays.append(uv0[:, :2])
    if uv0.shape[1] == 4:
        uv0[:, 3] = 1 - uv0[:, 3] 
        uv_arrays.append(uv0[:, 2:])

    return uv_arrays

def get_uv1(streams: dict[int, NDArray]) -> NDArray:
    uv1       = streams[1]["uv1"].copy()
    uv1[:, 1] = 1 - uv1[:, 1] 
    return uv1

def get_colours(streams: dict[int, NDArray], count: int) -> list[NDArray]:
    col_arrays = []
    for idx in range(count):
        field = f"colour{idx}"
        col_arrays.append(streams[1][field].view(ubyte) / 255.0)

    return col_arrays

def get_bitangents(streams: dict[int, NDArray]) -> NDArray:
    # The inverse of the exporter's encoding: flip axes after converting the bytes to floats
    # (negating a byte wraps), keep the sign out of the normalisation, and read the sign the
    # way byte_sign writes it (255 for a positive sign).
    stream_tangents   = streams[1]["tangent"]
    bitangents        = np.zeros(stream_tangents.shape, dtype=single)
    bitangents[:, :3] = xiv_to_blend_space(byte_to_vector(stream_tangents[:, :3]))
    bitangents[:, 3]  = np.where(stream_tangents[:, 3] >= 128, 1.0, -1.0)

    return bitangents
    
def get_flow(flow_vectors: NDArray, normals: NDArray, bitangents: NDArray) -> NDArray:
    # Normalising would give the zero vector (no direction) a direction; keep it at the centre.
    zero         = zero_flow_bytes(flow_vectors)
    flow_vectors = xiv_to_blend_space(byte_to_vector(flow_vectors))[:, :3]
    signs        = bitangents[:, 3]
    bitangents   = bitangents[:, :3]
    tangents     = calc_tangents_with_bitangent(normals, bitangents, signs)
    world_flow   = tangent_to_world_space(flow_vectors, tangents, bitangents, normals)
    quantised    = quantise_flow(world_flow[:, :2])

    colour = _flow_colour(quantised)
    colour[zero, :2] = ZERO_FLOW_COLOUR
    return colour
    
def _flow_colour(world_flow: NDArray) -> NDArray:
    rg_col = (normalise_vectors(world_flow) + 1.0) / 2.0
    ba_col = np.ones((len(world_flow), 2))
    
    return np.c_[rg_col, ba_col]
           