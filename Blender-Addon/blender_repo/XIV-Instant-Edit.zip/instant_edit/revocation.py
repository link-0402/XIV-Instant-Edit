"""Durable, authenticated revocation of plugin-owned export contexts."""

from __future__ import annotations

import json
import os
import queue
import threading
import uuid
from urllib.error import URLError

import bpy

from .cache import ensure_cache_root
from .context import _value
from .plugin_http import PluginResponseTooLarge, candidate_ports, post_json
from .diagnostics import record_failure, record_protocol_failure, record_remote_failure


SCHEMA = "instant-edit.pending-revocations"
VERSION = 1
REQUEST_TIMEOUT_SECONDS = 2
MAX_RESPONSE_SIZE = 64 * 1024

_lock = threading.RLock()
_results = queue.Queue()
_worker_running = False
_generation = 0


def _queue_path():
    return ensure_cache_root() / "pending-context-revocations.json"


def _load_locked() -> list[dict]:
    path = _queue_path()
    if not path.exists():
        return []
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise ValueError("pending context revocations are unreadable") from error
    if not isinstance(payload, dict) or payload.get("schema") != SCHEMA or payload.get("version") != VERSION:
        raise ValueError("pending context revocations have an invalid format")
    records = payload.get("revocations", [])
    if not isinstance(records, list):
        raise ValueError("pending context revocations have an invalid format")
    return [record for record in records if isinstance(record, dict)]


def _save_locked(records: list[dict]) -> None:
    path = _queue_path()
    temporary = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    payload = {"schema": SCHEMA, "version": VERSION, "revocations": records}
    try:
        with temporary.open("x", encoding="utf-8", newline="\n") as stream:
            json.dump(payload, stream, ensure_ascii=False, separators=(",", ":"))
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass


def queue_context_revocations(collections) -> int:
    """Persist tombstones before callers remove the scene's local metadata."""
    additions = []
    for collection in collections:
        context_id = _value(collection, "context_id", "")
        import_id = _value(collection, "import_id", "")
        capability = _value(collection, "capability", "")
        ports = candidate_ports(collection)
        if not all(isinstance(value, str) and value for value in (context_id, import_id, capability)) or not ports:
            raise ValueError(
                f"context {context_id or '<unknown>'} has incomplete revocation metadata"
            )
        additions.append({
            "contextId": context_id,
            "importId": import_id,
            "capability": capability,
            "ports": ports,
        })
    if not additions:
        return 0

    with _lock:
        records = _load_locked()
        known = {(item.get("contextId"), item.get("importId")) for item in records}
        for item in additions:
            key = (item["contextId"], item["importId"])
            if key not in known:
                records.append(item)
                known.add(key)
        _save_locked(records)
    return len(additions)


def _send(record: dict) -> bool:
    payload = {
        "schema": "instant-edit.context-revoke",
        "version": 1,
        "contextId": record.get("contextId"),
        "importId": record.get("importId"),
        "capability": record.get("capability"),
    }
    for port in record.get("ports", []):
        if not isinstance(port, int) or not 1 <= port <= 65535:
            continue
        try:
            status, response_body = post_json(
                port, "/context/revoke", payload,
                timeout=REQUEST_TIMEOUT_SECONDS, max_response_size=MAX_RESPONSE_SIZE)
            if 200 <= status < 300:
                try:
                    result = json.loads(response_body.decode("utf-8"))
                except (UnicodeError, json.JSONDecodeError):
                    record_protocol_failure(
                        response_body, status, endpoint="/context/revoke",
                        operation="context_revoke")
                    continue
                if isinstance(result, dict) and result.get("ok"):
                    return True
                record_protocol_failure(
                    response_body, status, endpoint="/context/revoke",
                    operation="context_revoke")
            else:
                record_remote_failure(
                    response_body, status, endpoint="/context/revoke",
                    default_operation="context_revoke")
        except PluginResponseTooLarge as error:
            record_protocol_failure(
                error.body,
                error.status,
                endpoint="/context/revoke",
                operation="context_revoke",
                code="response_too_large",
                cause="The Dalamud plugin returned a response larger than the bridge limit.",
            )
            continue
        except (URLError, TimeoutError, OSError, ValueError, UnicodeError):
            continue
    return False


def _worker(generation: int, records: list[dict]) -> None:
    completed = []
    try:
        for record in records:
            try:
                if _send(record):
                    completed.append((record.get("contextId"), record.get("importId")))
            except Exception as error:
                # An unexpected failure on one record must not stop the rest.
                # It stays queued and is retried the next time revocations run.
                record_failure(
                    component="blender_addon",
                    operation="context_revocation",
                    stage="revocation_request",
                    code="context_revocation_failed",
                    cause="Blender hit an unexpected error while revoking a plugin context.",
                    remedy="The revocation stays queued and is retried later.",
                    endpoint="/context/revoke",
                    exception=error,
                )
    finally:
        # Always report back. Until this result is polled, _worker_running
        # blocks schedule_revocations() and the poll timer never stops.
        _results.put((generation, completed))


def _poll_results():
    global _worker_running
    while True:
        try:
            generation, completed = _results.get_nowait()
        except queue.Empty:
            return 0.1
        if generation == _generation:
            break
    _worker_running = False
    if completed:
        completed = set(completed)
        try:
            with _lock:
                records = _load_locked()
                _save_locked([
                    item for item in records
                    if (item.get("contextId"), item.get("importId")) not in completed
                ])
        except Exception as error:
            record_failure(
                component="blender_addon",
                operation="context_revocation",
                stage="revocation_persistence",
                code="revocation_update_failed",
                cause="Blender could not update the pending context revocation queue.",
                remedy="Restart Blender and retry after the Dalamud plugin is running.",
                endpoint="/context/revoke",
                exception=error,
            )
            print(f"XIV Instant Edit: could not update context revocations: {error}")
    return None


def schedule_revocations() -> None:
    global _worker_running, _generation
    if _worker_running:
        return
    try:
        with _lock:
            records = _load_locked()
    except Exception as error:
        record_failure(
            component="blender_addon",
            operation="context_revocation",
            stage="revocation_persistence",
            code="revocation_queue_unavailable",
            cause="Blender could not load the pending context revocation queue.",
            remedy="Set a writable cache directory in XIV Instant Edit's in-game settings and restart Blender.",
            endpoint="/context/revoke",
            exception=error,
        )
        print(f"XIV Instant Edit: could not load context revocations: {error}")
        return
    if not records:
        return
    _generation += 1
    generation = _generation
    _worker_running = True
    threading.Thread(
        target=_worker,
        args=(generation, records),
        name="InstantEditContextRevocation",
        daemon=True,
    ).start()
    if not bpy.app.timers.is_registered(_poll_results):
        bpy.app.timers.register(_poll_results, first_interval=0.1)


def cancel_revocations() -> None:
    global _worker_running, _generation
    _generation += 1
    _worker_running = False
    try:
        bpy.app.timers.unregister(_poll_results)
    except Exception:
        pass
