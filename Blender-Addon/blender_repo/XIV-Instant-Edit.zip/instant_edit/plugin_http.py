"""Small shared HTTP client for loopback calls to the Dalamud plugin."""

import json
import urllib.request
from http.client import HTTPException
from urllib.error import HTTPError, URLError

from .context import _value


class PluginResponseTooLarge(ValueError):
    """The peer returned more response data than this bridge accepts."""

    def __init__(self, status: int, body: bytes):
        self.status = status
        self.body = body
        super().__init__("plugin response is too large")


def candidate_ports(collection) -> list[int]:
    ports = []
    stored = _value(collection, "callback_port", 0)
    if isinstance(stored, int) and 1 <= stored <= 65535:
        ports.append(stored)
    try:
        from ..preferences import get_prefs

        configured = get_prefs().instant_edit_plugin_port
        if isinstance(configured, int) and 1 <= configured <= 65535 and configured not in ports:
            ports.append(configured)
    except Exception:
        pass
    return ports


def post_json(
    port: int,
    endpoint: str,
    payload: dict,
    *,
    timeout: float,
    max_response_size: int,
) -> tuple[int, bytes]:
    """POST JSON and return status/body for both success and HTTP error responses.

    A failed exchange raises OSError (URLError and TimeoutError included) or
    PluginResponseTooLarge. A reply that is not valid HTTP, such as a garbled
    status line from another service on the port or a truncated chunked body,
    raises URLError like any other transport failure, so callers do not have to
    know http.client's exception hierarchy.
    """
    request = urllib.request.Request(
        f"http://127.0.0.1:{port}{endpoint}",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                status = getattr(response, "status", None) or response.getcode()
                body = response.read(max_response_size + 1)
        except HTTPError as error:
            # Reading the error body can fail the same way, and it happens
            # inside this handler, so the outer try is what catches it.
            status = error.code
            body = error.read(max_response_size + 1)
    except OSError:
        # RemoteDisconnected is both an OSError and an HTTPException.
        raise
    except HTTPException as error:
        raise URLError(f"HTTP protocol error: {error!r}") from error
    if len(body) > max_response_size:
        raise PluginResponseTooLarge(status, body)
    return status, body
