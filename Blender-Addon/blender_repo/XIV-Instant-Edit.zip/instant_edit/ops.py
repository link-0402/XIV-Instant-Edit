# Modified for XIV Instant Edit, 2026.
import bpy
from bpy.props import BoolProperty, StringProperty, EnumProperty
import json
import hashlib
import ntpath
import re
import threading
import uuid
import time
from contextlib import contextmanager
from functools import partial
from queue import Empty, Queue
from urllib.error import URLError

from pathlib   import Path
from bpy.types import Operator, Context

from ..io.model      import ModelImport
from ..materials     import (
    attribute_group_data, group_mesh_objects, hair_skeleton_tags,
    is_body_material,
)
from ..mesh.export   import (export_result, get_export_stats, check_triangulation, check_weights,
                             check_uv_layers, check_dropped_shape_keys, draw_dropped_shape_keys, flush_edit_mode,
                             ShapeExports)
from ..mesh.objects  import visible_meshobj
from ..properties    import get_settings
from ..xivpy.model   import XIVModel
from .props          import IN_PLACE_TARGET, NO_EXPORT_CONTEXT, get_instant_edit_props
from .context        import (SCHEMA, VERSION, SUPPORTED_VERSIONS, ContextValidationError,
                             _value, apply_authoritative_context, clear_context_metadata,
                             context_collections,
                             context_id_for_object, create_collection, mesh_ids_from_name,
                             mesh_name_info, MASHUP_SOURCE_MATERIAL_PROPERTY,
                             tag_object,
                             validate_context)
from .plugin_http    import PluginResponseTooLarge, post_json
from .material_preview import (cleanup_preview_bundle, discard_preview_data,
                               load_preview_manifest)
from .cache import create_job, finish_job
from .diagnostics import record_failure, record_protocol_failure, record_remote_failure
from .skeleton import create_armature, load_skeleton
from . import character as character_send, racial_scaling, sizes, steps


# ---- Dalamud plugin HTTP transport ----


def _physical_parent_path(file_path: str) -> str:
    """Return a model file's parent while preserving Windows bridge paths."""
    if (
        "\\" in file_path
        or bool(ntpath.splitdrive(file_path)[0])
    ):
        return ntpath.dirname(ntpath.normpath(file_path))
    return str(Path(file_path).resolve().parent)


MAX_PLUGIN_RESPONSE_SIZE = 64 * 1024
EXPORT_STATUS_POLL_ATTEMPTS = 30
INVALID_VARIANT_CHARS = frozenset('<>:"/\\|?*')
MASHUP_TARGET = "CREATE_MASHUP"
SAVE_NEW_MOD_TARGET = "SAVE_NEW_MOD"
# Meshes shaped for another race go into that race's own copy of the model (Save as c0801 Model).
RACE_TARGET = "RACE_MODEL"
MATERIAL_COVERAGE_SCHEMA = "instant-edit.material-coverage"
MATERIAL_COVERAGE_WARNING = (
    "Warning: the output mod is missing material or texture files from one or more non-active source mods. "
    "Use Create Mashup to include them."
)
UNSAFE_EXPORT_WARNING = (
    "This output may not work correctly without a mashup."
)
MATERIAL_COVERAGE_CACHE_SECONDS = 10.0
_material_coverage_cache: dict[str, tuple[float, tuple[str, ...]]] = {}
_material_coverage_pending: set[str] = set()
_material_coverage_results: Queue = Queue()
_material_coverage_lock = threading.Lock()
_material_coverage_generation = 0


class PluginResponseError(ValueError):
    def __init__(
        self,
        status: int | None,
        code: str,
        message: str,
        *,
        component: str = "dalamud_plugin",
        operation: str = "request",
        stage: str = "response_handling",
        remedy: str = "Update and restart both XIV Instant Edit components, then retry.",
        diagnostic_id: str = "",
    ):
        self.status = status
        self.code = code
        self.message = message
        self.component = component
        self.operation = operation
        self.stage = stage
        self.remedy = remedy
        self.diagnostic_id = diagnostic_id
        short_id = diagnostic_id[:8] if diagnostic_id else "unavailable"
        super().__init__(
            f"XIV Instant Edit {operation.replace('_', ' ')} failed during "
            f"{stage.replace('_', ' ')}: {message} {remedy} Diagnostic ID: {short_id}."
        )


def _plugin_operation(endpoint: str) -> str:
    return endpoint.strip("/").replace("/", "_").replace("-", "_") or "request"


def _plugin_response_too_large(
    error: PluginResponseTooLarge, endpoint: str
) -> PluginResponseError:
    failure = record_protocol_failure(
        error.body,
        error.status,
        endpoint=endpoint,
        operation=_plugin_operation(endpoint),
        code="response_too_large",
        cause="The Dalamud plugin returned a response larger than the bridge limit.",
    )
    return PluginResponseError(
        error.status,
        failure["code"],
        failure["cause"],
        component=failure["component"],
        operation=failure["operation"],
        stage=failure["stage"],
        remedy=failure["remedy"],
        diagnostic_id=failure["diagnosticId"],
    )


def _plugin_transport_error(
    error: BaseException,
    endpoint: str,
    cause: str,
    remedy: str,
) -> PluginResponseError:
    failure = record_failure(
        component="dalamud_plugin",
        operation=_plugin_operation(endpoint),
        stage="transport",
        code="plugin_connection_failed",
        cause=cause,
        remedy=remedy,
        endpoint=endpoint,
        exception=error,
    )
    return PluginResponseError(
        None,
        failure["code"],
        failure["cause"],
        component=failure["component"],
        operation=failure["operation"],
        stage=failure["stage"],
        remedy=failure["remedy"],
        diagnostic_id=failure["diagnosticId"],
    )


# ---- Material coverage checks (mashup contributor readiness) ----


def _normalize_mashup_material(material_name: str) -> str:
    normalized = re.sub(r"\.\d{3}$", "", (material_name or "").strip())
    if not normalized.casefold().endswith(".mtrl"):
        normalized += ".mtrl"
    if not normalized.startswith("/"):
        normalized = "/" + normalized
    return normalized


def _object_material_name(obj, *, source_material: bool = False) -> str:
    value = (
        obj.get(MASHUP_SOURCE_MATERIAL_PROPERTY, "")
        if source_material else obj.get("xiv_material", "")
    )
    if not value and source_material:
        value = obj.get("xiv_material", "")
    if not value and obj.material_slots and obj.material_slots[0].material is not None:
        value = obj.material_slots[0].material.name
    if not isinstance(value, str) or not value.strip():
        raise ContextValidationError(f"{obj.name}: missing material path")
    return _normalize_mashup_material(value)


def _collect_export_context_materials(context: Context, ref):
    """Collect context/material dependencies from exactly the selected export scope."""
    ref = ref or export_destination_context(context)
    props = get_instant_edit_props()
    objects = export_objects_for_scope(ref, getattr(props, "export_scope", "VISIBLE"))
    if not objects:
        raise ContextValidationError("No visible mesh objects match Export Parts.")

    refs = {ref.context_id: ref}
    materials: dict[str, list[str]] = {}
    context_order = [ref.context_id]
    object_contexts = {}
    for obj in objects:
        context_id = context_id_for_object(obj) or ref.context_id
        if context_id not in refs:
            refs[context_id] = validate_context(context_id, context.scene)
            context_order.append(context_id)
        material = _object_material_name(obj, source_material=True)
        context_materials = materials.setdefault(context_id, [])
        if material.casefold() not in {item.casefold() for item in context_materials}:
            context_materials.append(material)
        object_contexts[obj.as_pointer()] = (context_id, material)

    ordered_refs = [refs[key] for key in context_order if key in materials]
    return objects, ordered_refs, materials, object_contexts


def mashup_export_selection(context: Context, ref=None, *, minimum_contexts: int = 2):
    """Return (objects, refs, material map) for a dependency-aware export."""
    ref = ref or export_destination_context(context)
    objects, ordered_refs, materials, object_contexts = _collect_export_context_materials(context, ref)

    if ref.context_id not in materials:
        raise ContextValidationError("The active Context must contribute at least one exported mesh.")
    if len(materials) < minimum_contexts:
        raise ContextValidationError(
            "Create Mashup requires visible exported meshes from at least two Contexts."
            if minimum_contexts > 1 else
            "Save to new mod requires visible exported meshes from a Context."
        )
    refs = {item.context_id: item for item in ordered_refs}
    pending = [refs[context_id] for context_id in materials if refs[context_id].destination_state != "ready"]
    if pending:
        raise ContextValidationError("Create the Penumbra mod for every game-data Context before making a Mashup.")
    incomplete = [refs[context_id] for context_id in materials
                  if refs[context_id].resource_manifest_version != 2]
    if incomplete:
        raise ContextValidationError(
            "Dependency capture failed; re-import after resolving the missing resources: "
            + ", ".join(sorted({item.source_mod_name for item in incomplete})))

    return objects, ordered_refs, materials, object_contexts


def mashup_target_state(context: Context, ref=None) -> tuple[bool, bool, str]:
    try:
        ref = ref or export_destination_context(context)
        objects = export_objects_for_scope(
            ref, getattr(get_instant_edit_props(), "export_scope", "VISIBLE"))
        ids = {context_id_for_object(obj) or ref.context_id for obj in objects}
        if ref.context_id not in ids or len(ids) < 2:
            return False, False, ""
        refs = [validate_context(context_id, context.scene) for context_id in ids]
        if any(item.destination_state != "ready" for item in refs):
            return True, False, "Create the Penumbra mod for every game-data Context first."
        mashup_export_selection(context, ref)
        return True, True, ""
    except ContextValidationError as error:
        return True, False, str(error)


def _material_coverage_cache_key(context: Context, ref, refs, materials, objects) -> str:
    props = get_instant_edit_props()
    composition = {
        "scope": getattr(props, "export_scope", "VISIBLE"),
        "excluded": getattr(getattr(props, "export_excluded_mesh", None), "name", ""),
        "active": ref.context_id,
        "contexts": [
            {
                "contextId": item.context_id,
                "capability": item.capability,
                "sourceMod": item.source_mod_directory,
                "materials": list(materials[item.context_id]),
            }
            for item in refs
        ],
        "objects": [
            (
                getattr(obj, "name", ""),
                context_id_for_object(obj) or ref.context_id,
                _object_material_name(obj, source_material=True),
            )
            for obj in objects
        ],
    }
    return hashlib.sha256(
        json.dumps(composition, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()


def _material_coverage_payload(ref, contributors: list[dict]) -> dict:
    return {
        "schema": MATERIAL_COVERAGE_SCHEMA,
        "version": 1,
        "pluginInstanceId": ref.plugin_instance_id,
        "contextId": ref.context_id,
        "capability": ref.capability,
        "contributors": contributors,
    }


def _request_material_coverage(callback_port: int, payload: dict) -> tuple[str, ...]:
    try:
        status, body = post_json(
            callback_port, "/material-coverage", payload,
            timeout=3, max_response_size=MAX_PLUGIN_RESPONSE_SIZE)
        if not 200 <= status < 300:
            raise _plugin_error_from_body(body, status, "/material-coverage")
        result = _decode_plugin_response(body, status, "/material-coverage")
        available = result.get("available")
        covered = result.get("covered")
        if not isinstance(available, bool) or not isinstance(covered, bool):
            raise ValueError("plugin returned an invalid material coverage response")
        if not available or covered:
            return ()
        missing = result.get("missing")
        if not isinstance(missing, list) or not missing:
            raise ValueError("plugin returned an invalid missing material list")
        missing_materials = []
        seen = set()
        for item in missing:
            if not isinstance(item, dict):
                raise ValueError("plugin returned an invalid missing material entry")
            material = item.get("modelMaterial")
            if not isinstance(material, str) or not material.strip() or len(material) > 512:
                raise ValueError("plugin returned an invalid missing material name")
            material = _normalize_mashup_material(material)
            key = material.casefold()
            if key not in seen:
                seen.add(key)
                missing_materials.append(material)
        return tuple(missing_materials)
    except PluginResponseTooLarge as error:
        record_protocol_failure(
            error.body,
            error.status,
            endpoint="/material-coverage",
            operation="material_coverage",
            code="response_too_large",
            cause="The Dalamud plugin returned a response larger than the bridge limit.",
        )
        return ()
    except (URLError, TimeoutError, OSError, ValueError, UnicodeError):
        # Coverage is advisory. An unavailable or older plugin must not alter
        # the ordinary target eligibility or selection behavior.
        return ()


def _material_coverage_worker(
    generation: int,
    cache_key: str,
    callback_port: int,
    payload: dict,
) -> None:
    try:
        missing_materials = _request_material_coverage(callback_port, payload)
    except Exception:
        missing_materials = ()
    _material_coverage_results.put((generation, cache_key, missing_materials))


def _schedule_material_coverage(
    cache_key: str,
    callback_port: int,
    payload: dict,
) -> bool:
    with _material_coverage_lock:
        # Keep the advisory probe single-flight. If the composition changes
        # while a scan is running, the completion redraw schedules the newest
        # composition without stacking Penumbra scans behind the UI.
        if _material_coverage_pending:
            return False
        _material_coverage_pending.add(cache_key)
        generation = _material_coverage_generation
    try:
        threading.Thread(
            target=_material_coverage_worker,
            args=(generation, cache_key, callback_port, payload),
            name="XIV Instant Edit material coverage",
            daemon=True,
        ).start()
    except RuntimeError:
        with _material_coverage_lock:
            _material_coverage_pending.discard(cache_key)
        return False
    return True


def material_coverage_probe_pending() -> bool:
    with _material_coverage_lock:
        return bool(_material_coverage_pending)


def _is_general_material(material: str) -> bool:
    """Return whether a material is a shared body/general resource."""
    file_name = _normalize_mashup_material(material).rsplit("/", 1)[-1]
    lowered = file_name.casefold()
    return (
        is_body_material(file_name)
        or "pube" in lowered
        or "piercing" in lowered
    )


def poll_material_coverage_results() -> float:
    """Apply background probe results on Blender's main thread."""
    changed = False
    while True:
        try:
            generation, cache_key, missing_materials = _material_coverage_results.get_nowait()
        except Empty:
            break
        with _material_coverage_lock:
            if generation != _material_coverage_generation:
                continue
            _material_coverage_pending.discard(cache_key)
            _material_coverage_cache[cache_key] = (
                time.monotonic() + MATERIAL_COVERAGE_CACHE_SECONDS,
                tuple(missing_materials),
            )
            changed = True

    if changed:
        try:
            for window in bpy.context.window_manager.windows:
                for area in window.screen.areas:
                    area.tag_redraw()
        except (AttributeError, ReferenceError, RuntimeError):
            pass
    return 0.1 if material_coverage_probe_pending() else 1.0


def reset_material_coverage_state() -> None:
    global _material_coverage_generation
    with _material_coverage_lock:
        _material_coverage_generation += 1
        _material_coverage_cache.clear()
        _material_coverage_pending.clear()
    while True:
        try:
            _material_coverage_results.get_nowait()
        except Empty:
            break
    reset_export_readiness_cache()


def material_coverage_missing_materials(
    context: Context,
    ref=None,
    *,
    cache_only: bool = False,
    blocking: bool = False,
) -> tuple[str, ...]:
    """Return missing non-active materials cached for the export composition.

    With ``blocking``, a missing or stale answer is fetched from the plugin now instead of in
    the background, so a confirmation that depends on it can't be skipped."""
    try:
        ref = ref or export_destination_context(context)
        objects, refs, materials, _ = _collect_export_context_materials(context, ref)
        if ref.context_id not in materials or len(materials) < 2:
            return ()
        cache_key = _material_coverage_cache_key(context, ref, refs, materials, objects)
        now = time.monotonic()
        with _material_coverage_lock:
            cached = _material_coverage_cache.get(cache_key)
            if cached is not None:
                expires_at, missing_materials = cached
                if expires_at > now:
                    return missing_materials
                _material_coverage_cache.pop(cache_key, None)
            probe_running = bool(_material_coverage_pending)
        if cache_only:
            return ()

        if blocking:
            contributors = _material_coverage_contributor_payload(ref, refs, materials)
            if not contributors:
                return ()
            try:
                missing_materials = tuple(_request_material_coverage(
                    ref.callback_port, _material_coverage_payload(ref, contributors)))
            except Exception:
                # The export itself reports a plugin it can't reach.
                return ()
            with _material_coverage_lock:
                _material_coverage_cache[cache_key] = (
                    time.monotonic() + MATERIAL_COVERAGE_CACHE_SECONDS, missing_materials)
            return missing_materials

        if not probe_running:
            contributors = _material_coverage_contributor_payload(ref, refs, materials)
            if not contributors:
                return ()
            _schedule_material_coverage(
                cache_key,
                ref.callback_port,
                _material_coverage_payload(ref, contributors),
            )
        return ()
    except (ContextValidationError, AttributeError, RuntimeError, TypeError, ValueError):
        return ()


def material_coverage_warning_state(
    context: Context, ref=None, *, cache_only: bool = False, blocking: bool = False,
) -> bool:
    """Return whether the current export composition is missing non-active materials."""
    return bool(material_coverage_missing_materials(
        context, ref, cache_only=cache_only, blocking=blocking))


def quick_export_dropped_shape_keys(context: Context) -> list[str]:
    """Meshes of the current Export Parts that Quick Export writes without their shape keys."""
    try:
        ref = export_destination_context(context, persist=False)
        objects = export_objects_for_scope(ref, getattr(get_instant_edit_props(), "export_scope", "VISIBLE"))
    except ContextValidationError:
        return []
    return check_dropped_shape_keys(objects)


def unsafe_export_warning_state(context: Context, ref=None, *, blocking: bool = False) -> bool:
    """Return whether a non-mashup Quick Export needs explicit confirmation."""
    if getattr(get_instant_edit_props(), "variant_target", "") == MASHUP_TARGET:
        return False
    return material_coverage_warning_state(context, ref, blocking=blocking)


def save_new_mod_target_state(context: Context, ref=None) -> tuple[bool, bool, str]:
    """Return whether the single-context new-mod target is available."""
    try:
        ref = ref or export_destination_context(context)
        objects = export_objects_for_scope(
            ref, getattr(get_instant_edit_props(), "export_scope", "VISIBLE"))
        ids = {context_id_for_object(obj) or ref.context_id for obj in objects}
        if ref.context_id not in ids or len(ids) != 1:
            return False, False, ""
        mashup_export_selection(context, ref, minimum_contexts=1)
        return True, True, ""
    except ContextValidationError as error:
        return True, False, str(error)


def race_target_state(context: Context, ref=None) -> tuple[bool, int | None, str]:
    """Whether Save as Race Model is offered (some exported mesh is shaped for another race than the
    model's), the race it writes for (None when the meshes aren't shaped for one race), and why it
    can't, "" when it can."""
    try:
        ref = ref or export_destination_context(context, persist=False)
        objects = export_objects_for_scope(ref, getattr(get_instant_edit_props(), "export_scope", "VISIBLE"))
    except ContextValidationError as error:
        return False, None, str(error)
    found = racial_scaling.shaped_races(objects)
    if not found or set(found) == {racial_scaling.path_race(ref.source_game_path)}:
        return False, None, ""
    race, problem = racial_scaling.race_model(objects, ref.source_game_path)
    return True, race, problem


def race_target_label(race: int | None) -> str:
    """The Save as Race Model target's name: "Save as c0801 Model"."""
    return f"Save as c{race:04d} Model" if race else "Save as Race Model"


def wants_race_model(props, ref, objects) -> bool:
    """Whether Quick Export writes the meshes as their race's own model: the target is picked, or a game
    model's first export goes out racially scaled (its own race's model would refuse them)."""
    if ref.destination_state == "new_mod_required":
        return bool(racial_scaling.shaped_races(objects))
    return getattr(props, "variant_target", "") == RACE_TARGET


def racial_scaling_issue(props, ref, objects) -> str:
    """Why Quick Export refuses the meshes' racial scaling for its target, or "" when it doesn't."""
    if wants_race_model(props, ref, objects):
        return racial_scaling.race_model(objects, ref.source_game_path)[1]
    return racial_scaling.mismatch_refusal(objects, ref.source_game_path)


# ---- Variant target selection and validation ----


def normalise_variant_name(value: str) -> str:
    """Return a safe sibling .mdl file name without accepting a path."""
    name = (value or "").strip()
    if name.lower().endswith(".mdl"):
        name = name[:-4].rstrip()
    if not name or name in {".", ".."}:
        raise ValueError("Enter a variant name.")
    if len(name) > 120:
        raise ValueError("Variant name is too long.")
    if any(char in INVALID_VARIANT_CHARS or ord(char) < 32 for char in name):
        raise ValueError("Variant name contains characters that cannot be used in a file name.")
    return name


def validate_variant_name(source_game_path: str, variant_name: str) -> str:
    """Normalize a variant name and reject the original model's file name."""
    name = normalise_variant_name(variant_name)
    source_name = (source_game_path or "").replace("\\", "/").rsplit("/", 1)[-1]
    if source_name.lower().endswith(".mdl"):
        source_name = source_name[:-4]
    if source_name and name.casefold() == source_name.casefold():
        raise ValueError("Variant name must differ from the originally imported model name.")
    return name


def normalise_variant_group_name(value: str) -> str:
    """Return a safe Penumbra option-group name."""
    name = (value or "").strip()
    if not name:
        raise ValueError("Enter a Penumbra option group name.")
    if len(name) > 120:
        raise ValueError("Penumbra option group name is too long.")
    if any(ord(char) < 32 for char in name):
        raise ValueError("Penumbra option group name contains a control character.")
    return name


def _named_readiness_issue(label: str, names: list[str]) -> str:
    names = list(dict.fromkeys(str(name) for name in names if name))
    if not names:
        return label
    shown = ", ".join(names[:3])
    if len(names) > 3:
        shown += f", +{len(names) - 3} more"
    return f"{label} ({len(names)}): {shown}"


def _material_coverage_warning_message(missing_materials) -> str:
    names = list(dict.fromkeys(
        _normalize_mashup_material(name)
        for name in missing_materials
        if isinstance(name, str) and name.strip()
    ))
    if not names:
        return MATERIAL_COVERAGE_WARNING
    shown = ", ".join(names[:12])
    if len(names) > 12:
        shown += f", +{len(names) - 12} more"
    return (
        f"Warning: missing files for material{'s' if len(names) != 1 else ''} in this context: {shown}. "
        "Use Create Mashup to include them."
    )


_HAIR_MODEL_PATH = re.compile(
    r"chara/human/(c\d{4})/obj/hair/h\d{4}/model/c\d{4}h\d{4}_hir\.mdl", re.IGNORECASE)


def hair_skeleton_target_issue(game_path: str, entry: dict) -> str:
    """Return why the plugin will not set a tagged hair EST entry for this Context's model.

    The plugin checks every path the mod maps the model at; this mirrors the answer
    for the path the Context was imported from.
    """
    match = _HAIR_MODEL_PATH.fullmatch((game_path or "").replace("\\", "/").strip())
    if match is None:
        return (
            f"The meshes are weighted to hair skeleton {entry['entry']} ({entry['race']}), "
            "but this model is not hair; no EST entry will be set."
        )
    race = match.group(1).lower()
    if race != entry["race"]:
        return (
            f"The meshes are weighted to {entry['race']}'s hair skeleton {entry['entry']}, but this "
            f"hair is {race}'s. Skeleton IDs differ per race, so {race} gets no EST entry."
        )
    return ""


def sizes_export_issue(props, ref) -> str:
    """Why Quick Export can't go out at Magic Fit's sizes to the selected target, or "" when it can."""
    if ref.destination_state == "new_mod_required":
        return "Turn off Magic Fit Sizes and export once to create the mod."
    selection = getattr(props, "variant_target", "NEW_GROUP")
    if selection in {IN_PLACE_TARGET, RACE_TARGET}:
        return "Sizes go into an option group. Pick New Group or a group."
    if selection in {MASHUP_TARGET, SAVE_NEW_MOD_TARGET}:
        return "Sizes can't go into a mashup or a new mod."
    return ""


def export_target_issues(
    context: Context,
    ref=None,
    *,
    material_coverage_warning: bool | None = None,
) -> list[tuple[str, str]]:
    """Return grouped readiness issues for the current Quick Export target.

    This intentionally mirrors the export preflight checks without changing any
    export state.  Each tuple contains a severity (``ERROR`` or ``WARNING``)
    and a user-facing message.
    """
    props = get_instant_edit_props()
    issues: list[tuple[str, str]] = []
    if ref is None:
        try:
            ref = export_destination_context(context, persist=False)
        except ContextValidationError as error:
            return [("ERROR", str(error))]
    scope = getattr(props, "export_scope", "VISIBLE")

    try:
        export_objects = export_objects_for_scope(ref, scope)
    except ContextValidationError as error:
        export_objects = []
        issues.append(("ERROR", str(error)))

    if not export_objects:
        if not any(message == "No visible mesh objects match Export Parts." for _, message in issues):
            issues.append(("ERROR", "No visible mesh objects match Export Parts."))
    else:
        invalid_names = []
        empty_meshes = []
        missing_materials = []
        mesh_ids: dict[tuple[int, int, int], list[str]] = {}

        for obj in export_objects:
            name = getattr(obj, "name", "Unnamed mesh")
            if len(getattr(getattr(obj, "data", None), "vertices", ())) == 0:
                empty_meshes.append(name)
            try:
                mesh_id = mesh_ids_from_name(obj)
            except ContextValidationError:
                invalid_names.append(name)
            else:
                mesh_ids.setdefault(mesh_id, []).append(name)

            try:
                _object_material_name(obj)
            except (
                AttributeError,
                ContextValidationError,
                KeyError,
                ReferenceError,
                TypeError,
                ValueError,
            ):
                missing_materials.append(name)

        duplicate_ids = [
            name
            for names in mesh_ids.values()
            if len(names) > 1
            for name in names
        ]
        not_triangulated = check_triangulation(export_objects)
        unweighted = check_weights(export_objects)

        if invalid_names:
            issues.append((
                "ERROR",
                _named_readiness_issue("Invalid mesh names", invalid_names),
            ))
        if empty_meshes:
            issues.append((
                "ERROR",
                _named_readiness_issue("Empty meshes", empty_meshes),
            ))
        if duplicate_ids:
            issues.append((
                "ERROR",
                _named_readiness_issue("Duplicate mesh IDs", duplicate_ids),
            ))
        if missing_materials:
            issues.append((
                "ERROR",
                _named_readiness_issue("Missing material paths", missing_materials),
            ))
        if not_triangulated:
            issues.append((
                "ERROR",
                _named_readiness_issue("Not triangulated", not_triangulated),
            ))
        if unweighted:
            issues.append((
                "ERROR",
                _named_readiness_issue("No bone weights", unweighted),
            ))
        issues.extend(("ERROR", problem) for problem in check_uv_layers(export_objects))
        scaling_issue = racial_scaling_issue(props, ref, export_objects)
        if scaling_issue:
            issues.append(("ERROR", scaling_issue))
        dropped_shape_keys = check_dropped_shape_keys(export_objects)
        if dropped_shape_keys:
            issues.append((
                "WARNING",
                _named_readiness_issue("Shape keys left out (Keep Shape Keys is off)", dropped_shape_keys),
            ))
        est_entries, est_issue = hair_skeleton_tags(export_objects)
        if est_issue:
            issues.append(("WARNING", est_issue))
        elif est_entries:
            target_issue = hair_skeleton_target_issue(ref.source_game_path, est_entries[0])
            if target_issue:
                issues.append(("WARNING", target_issue))

    sized = sizes.wanted(props)
    if sized:
        issue = sizes_export_issue(props, ref)
        if issue:
            issues.append(("ERROR", issue))
        if not sizes.picked_names(context.scene):
            issues.append(("ERROR", sizes.NO_SIZES))
    selection = getattr(props, "variant_target", "NEW_GROUP")
    if selection == MASHUP_TARGET:
        show_target, enabled, message = mashup_target_state(context, ref)
        if not show_target:
            issues.append(("ERROR", "Create Mashup is unavailable for the current export selection."))
        elif not enabled:
            issues.append(("ERROR", message or "Create Mashup is not ready for the current export selection."))
    elif selection == SAVE_NEW_MOD_TARGET:
        show_target, enabled, message = save_new_mod_target_state(context, ref)
        if not show_target:
            issues.append(("ERROR", "Save to new mod is unavailable for the current export selection."))
        elif not enabled:
            issues.append(("ERROR", message or "Save to new mod is not ready for the current export selection."))
    elif selection == "NEW_GROUP":
        try:
            normalise_variant_group_name(getattr(props, "variant_group_name", ""))
        except ValueError as error:
            issues.append(("ERROR", str(error)))
        if not sized:
            try:
                validate_variant_name(ref.source_game_path, getattr(props, "variant_name", ""))
            except ValueError as error:
                issues.append(("ERROR", str(error)))
    elif selection not in {IN_PLACE_TARGET, RACE_TARGET}:
        target = selected_variant_target(props)
        if getattr(props, "variant_targets_context_id", "") != ref.context_id:
            issues.append(("ERROR", "Refresh targets for this Context before exporting."))
        elif target is None:
            issues.append(("ERROR", "The selected mod option is no longer available; refresh targets."))
        elif target.kind == "GROUP" and not sized:
            try:
                validate_variant_name(ref.source_game_path, getattr(props, "variant_name", ""))
            except ValueError as error:
                issues.append(("ERROR", str(error)))
        elif target.kind != "OPTION":
            issues.append(("ERROR", "The selected Penumbra target is invalid; refresh targets."))

    if material_coverage_warning is None:
        material_coverage_warning = material_coverage_warning_state(context, ref)
    if selection != MASHUP_TARGET:
        if material_coverage_warning:
            missing_materials = material_coverage_missing_materials(
                context, ref, cache_only=True)
            issues.append((
                "WARNING",
                _material_coverage_warning_message(missing_materials),
            ))
        elif material_coverage_probe_pending():
            issues.append(("WARNING", "Checking material and texture coverage…"))

    return issues


_EXPORT_READINESS_REFRESH_SECONDS = 0.1
_export_readiness_display_cache: dict = {
    "issues": (), "material_coverage_warning": False, "hair_skeleton": "",
}


def detected_hair_skeleton(ref) -> str:
    """Return "160 (c0801)" when Quick Export will set the meshes' tagged hair EST entry."""
    try:
        objects = export_objects_for_scope(ref, getattr(get_instant_edit_props(), "export_scope", "VISIBLE"))
    except ContextValidationError:
        return ""
    entries, _issue = hair_skeleton_tags(objects)
    if not entries or hair_skeleton_target_issue(ref.source_game_path, entries[0]):
        return ""
    return f"{entries[0]['entry']} ({entries[0]['race']})"


def _run_export_readiness_refresh() -> None:
    """Recompute the export readiness display cache and redraw if it changed.

    export_target_issues()/material_coverage_warning_state() re-scan every
    visible export object, and the panel that displays them gets redrawn by
    Blender far more often than the underlying scene actually changes (any
    viewport interaction can trigger it, not just XIV Instant Edit edits).
    Recomputing them synchronously inside draw() was a measured, significant
    cost on scenes with many parts. This mirrors _run_visibility_check's
    debounce: draw() only ever reads the cache below (request_export_readiness_
    refresh), and this does the real, fully-correct computation shortly after
    redraw activity settles.
    """
    context = bpy.context
    try:
        ref = export_destination_context(context, persist=False)
    except ContextValidationError as error:
        issues, warning, hair = [("ERROR", str(error))], False, ""
    else:
        warning = material_coverage_warning_state(context, ref)
        issues = export_target_issues(context, ref, material_coverage_warning=warning)
        hair = detected_hair_skeleton(ref)
    changed = (
        tuple(issues) != _export_readiness_display_cache["issues"]
        or warning != _export_readiness_display_cache["material_coverage_warning"]
        or hair != _export_readiness_display_cache["hair_skeleton"]
    )
    _export_readiness_display_cache["issues"] = tuple(issues)
    _export_readiness_display_cache["material_coverage_warning"] = warning
    _export_readiness_display_cache["hair_skeleton"] = hair
    if changed:
        try:
            for window in bpy.context.window_manager.windows:
                for area in window.screen.areas:
                    area.tag_redraw()
        except (AttributeError, ReferenceError, RuntimeError):
            pass
    return None


def request_export_readiness_refresh() -> None:
    """Debounce a background recompute of the export readiness display cache."""
    if bpy.app.timers.is_registered(_run_export_readiness_refresh):
        bpy.app.timers.unregister(_run_export_readiness_refresh)
    bpy.app.timers.register(_run_export_readiness_refresh, first_interval=_EXPORT_READINESS_REFRESH_SECONDS)


def cached_export_readiness() -> tuple[list[tuple[str, str]], bool]:
    """Return the last computed (issues, material_coverage_warning) for display.

    Always instant - this never performs the expensive scan itself, it only
    reads the last background-computed result and schedules a refresh.
    Callers that need a synchronous, guaranteed-fresh answer (e.g. actually
    gating an export) must call export_target_issues()/
    material_coverage_warning_state() directly instead - this cache can lag
    real scene state by up to _EXPORT_READINESS_REFRESH_SECONDS.
    """
    request_export_readiness_refresh()
    return (
        list(_export_readiness_display_cache["issues"]),
        _export_readiness_display_cache["material_coverage_warning"],
    )


def cached_hair_skeleton() -> str:
    """Return the last computed hair EST entry Quick Export will set, for display."""
    return _export_readiness_display_cache["hair_skeleton"]


def reset_export_readiness_cache() -> None:
    _export_readiness_display_cache["issues"] = ()
    _export_readiness_display_cache["material_coverage_warning"] = False
    _export_readiness_display_cache["hair_skeleton"] = ""
    try:
        bpy.app.timers.unregister(_run_export_readiness_refresh)
    except Exception:
        pass


def selected_variant_target(props):
    """Return the cached Penumbra target selected in the sidebar, if any."""
    selection = getattr(props, "variant_target", "NEW_GROUP")
    if selection in {"NEW_GROUP", IN_PLACE_TARGET}:
        return None
    return next((item for item in props.variant_targets if item.selection_id == selection), None)


def _request_variant_targets(ref) -> list[dict]:
    """Fetch the plugin-owned list of compatible Penumbra option targets."""
    payload = {
        "schema": "instant-edit.variant-targets",
        "version": 1,
        "pluginInstanceId": ref.plugin_instance_id,
        "contextId": ref.context_id,
        "capability": ref.capability,
    }
    try:
        status, body = post_json(
            ref.callback_port, "/variant-targets", payload,
            timeout=3, max_response_size=MAX_PLUGIN_RESPONSE_SIZE)
    except PluginResponseTooLarge as error:
        raise _plugin_response_too_large(error, "/variant-targets") from error
    except (URLError, TimeoutError, OSError) as error:
        raise _plugin_transport_error(
            error,
            "/variant-targets",
            "The Dalamud plugin could not be reached while loading variant targets.",
            "Start XIV Instant Edit in the game and retry.",
        ) from error
    if not 200 <= status < 300:
        raise _plugin_error_from_body(body, status, "/variant-targets")
    result = _decode_plugin_response(body, status, "/variant-targets")
    groups = result.get("groups", [])
    if not isinstance(groups, list):
        raise ValueError("plugin returned invalid Penumbra variant targets")
    return groups


def _normalise_variant_model_path(value: str) -> str:
    """Normalize a mod-relative model path for case-insensitive matching."""
    return str(value or "").replace("\\", "/").lstrip("/").casefold()


def refresh_variant_targets(
    context: Context,
    select_group_name: str | None = None,
    select_option_name: str | None = None,
) -> int:
    """Replace the cached tree with targets for the selected export context."""
    ref = export_destination_context(context)
    props = get_instant_edit_props()
    if ref.destination_state != "ready":
        props.variant_targets.clear()
        props.variant_targets_context_id = ref.context_id
        return 0
    groups = _request_variant_targets(ref)
    previous_targets_context_id = props.variant_targets_context_id
    props.variant_targets.clear()
    for group in groups:
        if not isinstance(group, dict):
            continue
        group_id = group.get("id")
        group_name = group.get("name")
        options = group.get("options")
        if not isinstance(group_id, str) or not isinstance(group_name, str) or not isinstance(options, list):
            continue
        group_item = props.variant_targets.add()
        group_item.selection_id = group_id
        group_item.kind = "GROUP"
        group_item.group_name = group_name
        for option in options:
            if not isinstance(option, dict):
                continue
            option_id = option.get("id")
            option_name = option.get("name")
            model_path = option.get("modelPath", "")
            if not isinstance(option_id, str) or not isinstance(option_name, str) or not isinstance(model_path, str):
                continue
            option_item = props.variant_targets.add()
            option_item.selection_id = option_id
            option_item.kind = "OPTION"
            option_item.group_name = group_name
            option_item.option_name = option_name
            option_item.model_path = model_path
            option_item.backup_target_id = str(option.get("backupTargetId", "") or "")
            option_item.backup_directory = str(option.get("backupDirectory", "") or "")
    props.variant_targets_context_id = ref.context_id
    selected_option = None
    if select_group_name is not None and select_option_name is not None:
        selected_option = next(
            (
                item for item in props.variant_targets
                if item.kind == "OPTION"
                and item.group_name.casefold() == select_group_name.casefold()
                and item.option_name.casefold() == select_option_name.casefold()
            ),
            None,
        )
    if selected_option is None and previous_targets_context_id != ref.context_id:
        imported_model_path = _normalise_variant_model_path(ref.target_relative_path)
        if imported_model_path:
            selected_option = next(
                (
                    item for item in props.variant_targets
                    if item.kind == "OPTION"
                    and _normalise_variant_model_path(item.model_path) == imported_model_path
                ),
                None,
            )
    if selected_option is not None:
        props.variant_target = selected_option.selection_id
    elif previous_targets_context_id != ref.context_id and not groups:
        props.variant_target = IN_PLACE_TARGET
    elif props.variant_target not in {
        "NEW_GROUP", IN_PLACE_TARGET, MASHUP_TARGET, SAVE_NEW_MOD_TARGET, RACE_TARGET,
    } and not any(
            item.selection_id == props.variant_target for item in props.variant_targets
    ):
        props.variant_target = "NEW_GROUP"
    return len(props.variant_targets)


def refresh_variant_targets_after_operation(
    context: Context,
    select_group_name: str | None = None,
    select_option_name: str | None = None,
) -> Exception | None:
    """Refresh the selected Context's target tree after an import or export.

    Standalone import/export can run without an XIV Instant Edit Context. In
    that case there is no target tree to refresh. A refresh failure must not
    turn an already-completed model operation into a failed operation, so the
    caller receives the error and can surface it as a warning instead.
    """
    try:
        export_destination_context(context, persist=False)
    except ContextValidationError:
        return None
    except Exception as error:
        return error
    try:
        refresh_variant_targets(
            context,
            select_group_name=select_group_name,
            select_option_name=select_option_name,
        )
    except Exception as error:
        return error
    return None


def variant_game_path(source_game_path: str, variant_name: str) -> str:
    directory, separator, _ = source_game_path.rpartition("/")
    if not separator:
        raise ValueError("The source model has no parent game directory.")
    return f"{directory}/{variant_name}.mdl"


# ---- Instant Import: object staging snapshot/restore ----


def _snapshot_object_state(context: Context) -> tuple:
    """Capture the user state that temporary armature setup can disturb."""
    return (
        tuple(context.selected_objects),
        context.view_layer.objects.active,
        context.mode,
    )


def _still_exists(obj) -> bool:
    """Whether a captured object is still in the file; a character send may have removed it."""
    if obj is None:
        return False
    try:
        return obj.name in bpy.data.objects
    except ReferenceError:
        return False


def _restore_object_state(context: Context, state: tuple) -> None:
    """Restore selection, active object, and mode without changing scene data."""
    selected, active, mode = state

    if context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    for obj in tuple(context.selected_objects):
        obj.select_set(False)
    for obj in selected:
        if _still_exists(obj):
            obj.select_set(True)

    context.view_layer.objects.active = active if _still_exists(active) else None
    if mode != "OBJECT" and context.view_layer.objects.active is not None:
        bpy.ops.object.mode_set(mode=mode)


def _finish_import_job(cache_job_directory: str) -> None:
    """Release an import's staged cache job; a job that is already gone is fine."""
    if not cache_job_directory:
        return
    try:
        finish_job(cache_job_directory)
    except OSError as error:
        print(f"XIV Instant Edit: could not remove import cache job: {error}")


def _remove_staging_objects(objects: list, collection) -> None:
    """Remove only objects recorded as belonging to this failed import."""
    seen = set()
    for obj in reversed(objects):
        if obj is None or obj.as_pointer() in seen:
            continue
        seen.add(obj.as_pointer())
        if obj.name not in bpy.data.objects:
            continue

        data = getattr(obj, "data", None)
        object_type = getattr(obj, "type", "")
        bpy.data.objects.remove(obj, do_unlink=True)
        # Imported mesh/armature datablocks are safe to discard when no other
        # object uses them. Materials are deliberately not removed.
        if data is not None and getattr(data, "users", 1) == 0:
            data_collection = {
                "MESH": bpy.data.meshes,
                "ARMATURE": bpy.data.armatures,
            }.get(object_type)
            if data_collection is not None and data.name in data_collection:
                data_collection.remove(data)

    if collection is not None and collection.name in bpy.data.collections:
        bpy.data.collections.remove(collection, do_unlink=True)


# ---- Instant Import operator (Dalamud-bridge driven import) ----


class InstantImport(Operator):
    bl_idname      = "xiv_ie.instant_import"
    bl_label       = "Instant Import"
    bl_description = "Imports a model sent by the XIV Instant Edit plugin into the active scene"
    bl_options     = {"UNDO"}

    file_path: bpy.props.StringProperty(options={'HIDDEN'})  # type: ignore
    object_index: bpy.props.IntProperty(default=-1, options={'HIDDEN'})  # type: ignore
    import_name: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore
    callback_port: bpy.props.IntProperty(default=0, options={'HIDDEN'})  # type: ignore
    schema: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore
    version: bpy.props.IntProperty(default=0, options={'HIDDEN'})  # type: ignore
    plugin_instance_id: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore
    context_id: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore
    capability: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore
    source_game_path: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore
    source_kind: bpy.props.StringProperty(default="mod", options={'HIDDEN'})  # type: ignore
    resolved_game_path: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore
    destination_state: bpy.props.StringProperty(default="ready", options={'HIDDEN'})  # type: ignore
    managed_destination: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore
    target_file_path: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore
    source_mod_directory: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore
    source_mod_stable_id: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore
    source_mod_name: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore
    source_mod_root_path: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore
    target_relative_path: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore
    target_collection_id: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore
    target_collection_name: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore
    resource_manifest_version: bpy.props.IntProperty(default=0, options={'HIDDEN'})  # type: ignore
    resource_manifest_status: bpy.props.StringProperty(default="capture_failed", options={'HIDDEN'})  # type: ignore
    backup_target_id: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore
    backup_directory: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore
    import_id: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore
    armature_mode: bpy.props.EnumProperty(
        items=[
            ("generated", "Generated", "Create an armature for this import"),
            ("existing", "Existing", "Use an existing scene armature"),
        ],
        default="generated",
        options={'HIDDEN'},
    )  # type: ignore
    armature_target: bpy.props.StringProperty(default="Skeleton", options={'HIDDEN'})  # type: ignore
    apply_textures_and_materials: bpy.props.BoolProperty(default=False, options={'HIDDEN'})  # type: ignore
    preview_manifest_path: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore
    # The game skeleton the plugin sent (see skeleton.stage_skeleton); empty for placeholder bones.
    skeleton_path: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore
    # "c0201 to c0801" when the plugin sent the model racially scaled; stamped on every mesh.
    racial_scaling: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore
    # A model of a whole-character send, as JSON (see character.py): it binds to the send's
    # shared armature instead of the armature mode's.
    character: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore
    cache_job_directory: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        return context.mode == "OBJECT"

    def execute(self, context: Context):
        props     = get_instant_edit_props()
        file_path = Path(self.file_path)
        user_state = _snapshot_object_state(context)
        created_objects = []
        collection = None
        preview_package = None
        preview_validation_warning = ""
        skeleton_note = ""
        # What a character send hid of the model because the game doesn't draw it; not a warning.
        drawn_note = ""
        character = None
        if not file_path.is_file():
            # Return before the try/finally below, so release the staged job here.
            _finish_import_job(self.cache_job_directory)
            props.last_status = "Import failed: file not found."
            self.report({"ERROR"}, "Model file not found.")
            return {"CANCELLED"}

        try:
            if self.schema != SCHEMA or self.version not in SUPPORTED_VERSIONS:
                raise ValueError("Import context has an unsupported schema or version")
            character = character_send.from_property(self.character)
            context_metadata = {
                "context_id": self.context_id,
                "schema": self.schema,
                "version": self.version,
            }
            collection_metadata = {
                **context_metadata,
                "plugin_instance_id": self.plugin_instance_id,
                "capability": self.capability,
                "source_game_path": self.source_game_path,
                "source_kind": self.source_kind,
                "resolved_game_path": self.resolved_game_path,
                "destination_state": self.destination_state,
                "managed_destination": self.managed_destination,
                "target_file_path": self.target_file_path,
                "source_mod_directory": self.source_mod_directory,
                "source_mod_stable_id": self.source_mod_stable_id,
                "source_mod_name": self.source_mod_name,
                "source_mod_root_path": self.source_mod_root_path,
                "target_relative_path": self.target_relative_path,
                "target_collection_id": self.target_collection_id,
                "target_collection_name": self.target_collection_name,
                "resource_manifest_version": self.resource_manifest_version,
                "resource_manifest_status": self.resource_manifest_status,
                "backup_target_id": self.backup_target_id,
                "backup_directory": self.backup_directory,
                "import_id": self.import_id,
                "callback_port": self.callback_port,
                "import_file_name": file_path.name,
            }

            collection_metadata["import_file_name"] = file_path.name

            collection = create_collection(context.scene, collection_metadata)

            if self.apply_textures_and_materials:
                if self.preview_manifest_path:
                    try:
                        preview_package = load_preview_manifest(self.preview_manifest_path, str(file_path))
                    except Exception as error:
                        preview_validation_warning = f"Material preview unavailable: {error}"
                else:
                    preview_validation_warning = "Material preview unavailable: the plugin did not provide a bundle."

            object_label = self.import_name or file_path.stem
            imported_meshes = ModelImport.from_file(
                str(file_path), object_label,
                collection=collection, context_metadata=context_metadata,
                select_objects=False,
                require_collection=True,
                created_objects=created_objects,
                material_preview=preview_package,
                material_context_key=self.context_id or collection.name,
            )
            if character is not None:
                skeleton_note, drawn_note = self._bind_character(
                    context,
                    file_path,
                    imported_meshes,
                    collection,
                    context_metadata,
                    created_objects,
                    character,
                )
            elif self.armature_mode == "existing":
                self._bind_existing_armature(
                    context,
                    imported_meshes,
                    collection,
                    self.armature_target,
                    created_objects,
                )
            else:
                skeleton_note = self._create_armature(
                    context,
                    file_path,
                    imported_meshes,
                    collection,
                    context_metadata,
                    created_objects,
                )

            for obj in imported_meshes:
                tag_object(obj, context_metadata)
            racial_scaling.mark(imported_meshes, self.racial_scaling)

            props.game_path    = self.source_game_path
            props.object_index = self.object_index
            props.display_name = file_path.name
            props.context_id = self.context_id
            props.context_schema = self.schema
            props.context_version = self.version
            props.plugin_instance_id = self.plugin_instance_id
            props.capability = self.capability
            props.managed_destination = self.managed_destination
            if (
                self.source_kind == "mod"
                and self.target_file_path
                and get_settings().simple_import_set_export_directory
            ):
                get_settings().export_directory = _physical_parent_path(self.target_file_path)
            preview_warnings = [] if preview_package is None else preview_package.warnings
            warning_text = preview_validation_warning
            if preview_warnings:
                warning_text = "; ".join(preview_warnings[:3])
                if len(preview_warnings) > 3:
                    warning_text += f" (+{len(preview_warnings) - 3} more)"
            props.last_status = (
                f"Imported {file_path.name} with preview warnings: {warning_text}"
                if warning_text else f"Imported {file_path.name}"
            )
            for note in (skeleton_note, drawn_note):
                if note:
                    props.last_status += f"; {note}"
            context_selection_changed = _preselect_sole_export_context(
                props, context, self.context_id)
        except Exception as e:
            _remove_staging_objects(created_objects, collection)
            if character is not None:
                try:
                    character_send.discard_if_empty(context.scene, character)
                except Exception as cleanup_error:
                    print(f"XIV Instant Edit: could not remove an empty character collection: {cleanup_error}")
            discard_preview_data(preview_package)
            props.last_status = f"Import failed: {e}"
            self.report({"ERROR"}, f"Import failed: {e}")
            return {"CANCELLED"}

        finally:
            try:
                _restore_object_state(context, user_state)
                cleanup_preview_bundle(preview_package)
            finally:
                _finish_import_job(self.cache_job_directory)

        # Changing the selector already invokes the same refresh through the
        # property update callback. Avoid issuing that bridge request twice,
        # while still refreshing imports into an already-selected Context.
        refresh_error = None
        if (
            not context_selection_changed
            or props.variant_targets_context_id != props.export_destination
        ):
            refresh_error = refresh_variant_targets_after_operation(context)
        if refresh_error is not None:
            props.last_status += f"; Penumbra targets could not refresh: {refresh_error}"
        if preview_validation_warning or (preview_package is not None and preview_package.warnings):
            self.report({"WARNING"}, props.last_status)
        elif refresh_error is not None or skeleton_note:
            self.report({"WARNING"}, props.last_status)
        else:
            self.report({"INFO"}, props.last_status if drawn_note else "Model imported!")
        return {"FINISHED"}

    def _bind_existing_armature(
        self,
        context: Context,
        mesh_objects,
        collection,
        target_name: str,
        created_objects=None,
    ) -> None:
        """Bind only this import's meshes to an existing scene armature."""
        target = context.scene.objects.get(target_name.strip())
        if target is None:
            raise ValueError(f'Armature object "{target_name}" was not found in the active scene')
        if target.type != "ARMATURE":
            raise ValueError(f'Blender object "{target.name}" is not an Armature')

        # ModelImport currently returns meshes only. Keep this cleanup scoped to
        # objects recorded by this import for compatibility with importers that
        # may also stage the source armature in the future.
        for obj in tuple(created_objects or ()):
            if obj.type != "ARMATURE" or collection not in obj.users_collection:
                continue
            for mesh in mesh_objects:
                if mesh.parent == obj:
                    mesh.parent = None
            data = obj.data
            bpy.data.objects.remove(obj, do_unlink=True)
            if data is not None and data.users == 0 and data.name in bpy.data.armatures:
                bpy.data.armatures.remove(data)

        for obj in tuple(mesh_objects):
            if (
                obj.type != "MESH"
                or collection not in obj.users_collection
                or (created_objects is not None and obj not in created_objects)
            ):
                raise ValueError("import returned an object outside its staging collection")

            # Imported meshes are new, but remove any armature modifiers supplied
            # by a future importer before assigning the requested target.
            for modifier in tuple(obj.modifiers):
                if modifier.type == "ARMATURE":
                    obj.modifiers.remove(modifier)
            obj.parent = None
            modifier = obj.modifiers.new(name="Armature", type="ARMATURE")
            modifier.object = target

    def _create_armature(
        self,
        context: Context,
        file_path: Path,
        mesh_objects,
        collection,
        metadata=None,
        created_objects=None,
    ) -> str:
        """Creates an armature with the game's skeleton and every bone of the model, and parents
        the returned imported mesh to it, so the standard export pipeline can run. Returns a note
        for the status line, or an empty string."""
        model = XIVModel.from_file(str(file_path))
        _check_unbound_meshes(mesh_objects, collection, created_objects)
        game_skeleton, skeleton_error = self._load_game_skeleton()
        armature_obj, report = create_armature(
            context, collection, "InstantEditArmature", model.bones, mesh_objects, game_skeleton,
            created_objects=created_objects)
        if metadata:
            tag_object(armature_obj, metadata)

        for obj in tuple(mesh_objects):
            obj.parent = armature_obj
            modifier   = obj.modifiers.new(name="Armature", type="ARMATURE")
            modifier.object = armature_obj
        # Keep the bones out of the viewport; the hidden armature still deforms its meshes.
        armature_obj.hide_set(True)
        return skeleton_error or report.summary()

    def _bind_character(
        self,
        context: Context,
        file_path: Path,
        mesh_objects,
        collection,
        metadata,
        created_objects,
        character,
    ) -> tuple[str, str]:
        """Binds a model of a whole-character send (see character.py): body models to the send's
        shared armature, a weapon to an armature of its own hung from the bone that holds it, then
        shows the model as the game draws it. A new send of the character first replaces its
        previous one. Returns a warning for the status line and what the game hides of the model,
        each an empty string when there is nothing to say."""
        character_send.replace_previous(context.scene, character)
        model = XIVModel.from_file(str(file_path))
        if character.role == character_send.WEAPON:
            note = self._create_armature(context, file_path, mesh_objects, collection, metadata, created_objects)
            armature = next((obj for obj in reversed(created_objects) if obj.type == "ARMATURE"), None)
            hang_note = (character_send.hang_weapon(context, character, armature, mesh_objects)
                         if armature is not None else "")
            character_send.adopt_collection(context.scene, character, collection)
            drawn_note = character_send.apply_draw_state(model, mesh_objects, character)
            return "; ".join(part for part in (note, hang_note) if part), drawn_note
        _check_unbound_meshes(mesh_objects, collection, created_objects)
        game_skeleton, skeleton_error = self._load_game_skeleton()
        note = character_send.bind_body(
            context, character, collection, mesh_objects, model.bones, game_skeleton, created_objects)
        drawn_note = character_send.apply_draw_state(model, mesh_objects, character)
        return skeleton_error or note, drawn_note

    def _load_game_skeleton(self):
        """The game skeleton the plugin sent, or None, and why it could not be read."""
        if not self.skeleton_path:
            return None, ""
        try:
            return load_skeleton(self.skeleton_path), ""
        except Exception as error:
            return None, f"the game skeleton could not be read ({error}); bones have no rest pose"


def _check_unbound_meshes(mesh_objects, collection, created_objects) -> None:
    """Refuses imported meshes that are not this import's own, unparented, staged meshes."""
    for obj in tuple(mesh_objects):
        if (
            obj.type != "MESH"
            or collection not in obj.users_collection
            or (created_objects is not None and obj not in created_objects)
        ):
            raise ValueError("import returned an object outside its staging collection")
        if obj.parent:
            raise ValueError("import returned an already-parented mesh")


# ---- Mashup export context management ----


def _valid_export_contexts(context: Context) -> list:
    refs = []
    for collection in context_collections(context.scene):
        context_id = _value(collection, "context_id", "")
        try:
            refs.append(validate_context(context_id, context.scene))
        except ContextValidationError:
            continue
    return refs


def _preselect_sole_export_context(
    props, context: Context, imported_context_id: str
) -> bool:
    """Store one concrete context ID without reintroducing an active-context fallback."""
    previous_selection = props.export_destination
    refs = _valid_export_contexts(context)
    valid_ids = {ref.context_id for ref in refs}
    selected = getattr(props, "export_destination", NO_EXPORT_CONTEXT)
    if len(refs) == 1 and refs[0].context_id == imported_context_id:
        props.export_destination = imported_context_id
    elif selected == "ACTIVE" or (
        selected != NO_EXPORT_CONTEXT and selected not in valid_ids
    ):
        # A saved pre-explicit selector must never choose a context implicitly
        # when more than one valid destination now exists.
        props.export_destination = NO_EXPORT_CONTEXT
    return props.export_destination != previous_selection


def _mashup_context_metadata(payload: dict, target_file_path: str) -> dict:
    """Convert a plugin-created output context into collection metadata."""
    if not isinstance(payload, dict):
        raise ContextValidationError("plugin returned an invalid mashup output context")

    schema = payload.get("schema")
    version = payload.get("version")
    context_id = payload.get("contextId")
    import_id = payload.get("importId")
    callback_port = payload.get("callbackPort")
    if schema != SCHEMA or version not in SUPPORTED_VERSIONS:
        raise ContextValidationError("plugin returned an unsupported mashup output context")
    if not all(isinstance(value, str) and value for value in (
        context_id, import_id, payload.get("pluginInstanceId"),
        payload.get("capability"), payload.get("sourceGamePath"),
    )):
        raise ContextValidationError("plugin returned an incomplete mashup output context")
    if isinstance(callback_port, bool) or not isinstance(callback_port, int):
        raise ContextValidationError("plugin returned an invalid mashup output callback port")

    output_path = str(target_file_path or payload.get("targetFilePath") or "")
    if not output_path:
        raise ContextValidationError("plugin returned an incomplete mashup output path")

    return {
        "context_id": context_id,
        "schema": schema,
        "version": version,
        "plugin_instance_id": payload["pluginInstanceId"],
        "capability": payload["capability"],
        "source_game_path": payload["sourceGamePath"],
        "source_kind": payload.get("sourceKind") or "mod",
        "resolved_game_path": payload.get("resolvedGamePath") or payload["sourceGamePath"],
        "destination_state": payload.get("destinationState") or "ready",
        "managed_destination": payload.get("managedDestination") or "",
        "target_file_path": output_path,
        "source_mod_directory": payload.get("sourceModDirectory") or "",
        "source_mod_stable_id": payload.get("sourceModStableId") or "",
        "source_mod_name": payload.get("sourceModName") or "",
        "source_mod_root_path": payload.get("sourceModRootPath") or "",
        "target_relative_path": payload.get("targetRelativePath") or "",
        "target_collection_id": payload.get("targetCollectionId") or "",
        "target_collection_name": payload.get("targetCollectionName") or "",
        "resource_manifest_version": payload.get("resourceManifestVersion") or 0,
        "resource_manifest_status": payload.get("resourceManifestStatus") or "capture_failed",
        "backup_target_id": payload.get("backupTargetId") or "",
        "backup_directory": payload.get("backupDirectory") or "",
        "import_id": import_id,
        "callback_port": callback_port,
        "import_file_name": Path(output_path).name,
    }


def _mashup_duplicate_name(obj, context_id: str) -> str:
    """Create a unique name that retains the object's YAA mesh identity."""
    info = mesh_name_info(obj)
    lod = f" LOD{info.lod}" if info.lod else ""
    prefix = f"{info.mesh_group}.{info.mesh_part} "
    tag = f" [Mashup {context_id[:8]}]"
    # Keep LOD at the very end, after any counter: mesh_name_info reads the terminal LOD
    # suffix to recover the YAA identity. Blender 4.5 cuts names at 63 bytes, so shorten
    # the label rather than lose the suffix.
    room = 63 - len(f"{prefix}{tag} 9999{lod}".encode("utf-8"))
    label = (info.label or "Mashup").encode("utf-8")[:max(room, 1)].decode("utf-8", "ignore").rstrip()
    base = f"{prefix}{label or 'Mashup'}{tag}"
    candidate = f"{base}{lod}"
    suffix = 2
    existing = {item.name for item in bpy.data.objects}
    while candidate in existing:
        candidate = f"{base} {suffix}{lod}"
        suffix += 1
    return candidate


def _create_mashup_output_context(
    context: Context,
    payload: dict,
    target_file_path: str,
    export_objects: list,
    object_contexts: dict,
    assignments: dict[tuple[str, str], str],
):
    """Create a destination context from existing scene meshes, never an MDL import."""
    metadata = _mashup_context_metadata(payload, target_file_path)
    collection = create_collection(context.scene, metadata)
    created_objects = []
    try:
        output_context_id = metadata["context_id"]
        for obj in export_objects:
            source_context_id, source_material = object_contexts[obj.as_pointer()]
            alias = assignments[(source_context_id, source_material.casefold())]
            duplicate = obj.copy()
            duplicate.data = obj.data.copy()
            duplicate.name = _mashup_duplicate_name(obj, output_context_id)
            collection.objects.link(duplicate)
            tag_object(duplicate, {
                "context_id": output_context_id,
                "schema": metadata["schema"],
                "version": metadata["version"],
            })
            duplicate["xiv_material"] = alias
            duplicate["instant_edit_xiv_material"] = alias
            duplicate.pop(MASHUP_SOURCE_MATERIAL_PROPERTY, None)
            created_objects.append(duplicate)

        return validate_context(output_context_id, context.scene), created_objects
    except Exception:
        for obj in reversed(created_objects):
            if obj.name in bpy.data.objects:
                bpy.data.objects.remove(obj, do_unlink=True)
        if collection.name in bpy.data.collections:
            bpy.data.collections.remove(collection, do_unlink=True)
        raise


MASHUP_ALIAS_CONTEXT_PROPERTY = "instant_edit_mashup_alias_context"


def _persist_mashup_assignments(export_objects, object_contexts, assignments, alias_context_id) -> None:
    """Keep active-mod mashup aliases while retaining source materials for planning."""
    for obj in export_objects:
        context_id, source_material = object_contexts[obj.as_pointer()]
        alias = assignments[(context_id, source_material.casefold())]
        obj[MASHUP_SOURCE_MATERIAL_PROPERTY] = source_material
        # The aliases only resolve in the mod the mashup was written into.
        obj[MASHUP_ALIAS_CONTEXT_PROPERTY] = alias_context_id
        obj["xiv_material"] = alias
        obj["instant_edit_xiv_material"] = alias


def _use_mashup_source_materials(export_objects, context_id) -> list:
    """Export mashup-aliased objects with their source material outside the mashup's Context."""
    saved = []
    for obj in export_objects:
        source_material = obj.get(MASHUP_SOURCE_MATERIAL_PROPERTY)
        alias_context_id = obj.get(MASHUP_ALIAS_CONTEXT_PROPERTY)
        if not source_material or not alias_context_id or alias_context_id == context_id:
            continue
        properties = [(name, name in obj, obj.get(name))
                      for name in ("xiv_material", "instant_edit_xiv_material")]
        saved.append((obj, properties))
        for name, existed, _previous in properties:
            if name == "xiv_material" or existed:
                obj[name] = source_material
    return saved


def _restore_object_materials(saved) -> None:
    for obj, properties in reversed(saved):
        if obj.name not in bpy.data.objects:
            continue
        for name, existed, previous in properties:
            if existed:
                obj[name] = previous
            else:
                obj.pop(name, None)


class RefreshVariantTargets(Operator):
    bl_idname = "xiv_ie.refresh_variant_targets"
    bl_label = "Refresh Penumbra Targets"
    bl_description = "Load compatible option groups from the selected Context source mod"

    def execute(self, context: Context):
        try:
            count = refresh_variant_targets(context)
        except Exception as error:
            get_instant_edit_props().last_status = f"Could not load Penumbra targets: {error}"
            self.report({"ERROR"}, f"Could not load Penumbra targets: {error}")
            return {"CANCELLED"}
        self.report({"INFO"}, f"Loaded {count} compatible Penumbra target(s).")
        return {"FINISHED"}


class SelectVariantTarget(Operator):
    bl_idname = "xiv_ie.select_variant_target"
    bl_label = "Select Penumbra Target"
    bl_description = "Use this export target for the next Quick Export"
    bl_options = {"INTERNAL"}

    selection_id: StringProperty(options={"HIDDEN", "SKIP_SAVE"})  # type: ignore

    @classmethod
    def description(cls, context, properties):
        selection_id = getattr(properties, "selection_id", "")
        missing_materials = material_coverage_missing_materials(
            context, cache_only=True)
        if selection_id != MASHUP_TARGET and missing_materials:
            return _material_coverage_warning_message(missing_materials)
        if selection_id == "NEW_GROUP":
            return "Creates a new Group on Export. Define group and option names below."
        if selection_id == IN_PLACE_TARGET:
            return "Overwrites the imported model at its original path without changing Penumbra option groups."
        if selection_id == MASHUP_TARGET:
            return "Combines the visible exported meshes and their material and texture dependencies."
        if selection_id == SAVE_NEW_MOD_TARGET:
            return "Saves the visible model as a new mod, bundling participating-mod resources and retaining external dependencies."
        if selection_id == RACE_TARGET:
            _shown, race, problem = race_target_state(context)
            if problem or race is None:
                return problem or cls.bl_description
            return (
                f"Saves the model as a c{race:04d} file next to the imported one and maps it in the same options, "
                f"so {racial_scaling.race_label(race)} characters wear it.")
        try:
            target = next(
                (
                    item for item in get_instant_edit_props().variant_targets
                    if item.selection_id == selection_id
                ),
                None,
            )
        except (AttributeError, RuntimeError):
            target = None
        if target is not None and target.kind == "GROUP":
            return "Creates a new Option in this group. Define the option name below."
        if target is not None and target.kind == "OPTION":
            return "Overwrites this mod option within the group."
        return cls.bl_description

    def execute(self, _context):
        get_instant_edit_props().variant_target = self.selection_id
        return {"FINISHED"}


class SelectExportContext(Operator):
    bl_idname = "xiv_ie.select_export_context"
    bl_label = "Select Context"
    bl_description = "Export this Context with Quick Export"
    bl_options = {"INTERNAL"}

    context_id: StringProperty(options={"HIDDEN", "SKIP_SAVE"})  # type: ignore

    @classmethod
    def description(cls, context, properties):
        try:
            validate_context(properties.context_id, context.scene)
        except ContextValidationError as error:
            return f"This Context cannot be exported: {error}"
        return cls.bl_description

    def execute(self, context: Context):
        try:
            validate_context(self.context_id, context.scene)
        except ContextValidationError as error:
            self.report({"ERROR"}, f"This Context cannot be exported: {error}")
            return {"CANCELLED"}
        props = get_instant_edit_props()
        if props.export_destination != self.context_id:
            # The enum update refreshes the Penumbra targets for the new Context.
            props.export_destination = self.context_id
        return {"FINISHED"}


class OpenContextFolder(Operator):
    bl_idname = "xiv_ie.open_context_folder"
    bl_label = "Open Mod Folder"
    bl_description = "Open the selected Context's Penumbra mod folder"

    @classmethod
    def poll(cls, context: Context):
        try:
            ref = export_destination_context(context, persist=False)
        except ContextValidationError as error:
            cls.poll_message_set(str(error))
            return False
        if not ref.source_mod_root_path:
            cls.poll_message_set("This Context has no mod folder yet")
            return False
        return True

    def execute(self, context: Context):
        folder = export_destination_context(context, persist=False).source_mod_root_path
        try:
            result = bpy.ops.wm.path_open(filepath=folder)
        except RuntimeError as error:
            self.report({"ERROR"}, f"Could not open the mod folder: {error}")
            return {"CANCELLED"}
        if "FINISHED" not in result:
            self.report({"ERROR"}, "Could not open the mod folder.")
            return {"CANCELLED"}
        return {"FINISHED"}


# ---- Quick Export operator (Dalamud-bridge driven export) ----


class QuickExport(Operator):
    bl_idname      = "xiv_ie.instant_export"
    bl_label       = "Quick Export"
    bl_description = "Exports the current model back to the game path it was imported from via Penumbra"
    bl_options     = {"UNDO"}

    @classmethod
    def poll(cls, context: Context):
        try:
            export_destination_context(context, persist=False)
            return True
        except ContextValidationError as error:
            cls.poll_message_set(str(error))
            return False

    def invoke(self, context: Context, event):
        props = get_instant_edit_props()
        try:
            ref = export_destination_context(context)
            issue = sizes_export_issue(props, ref) if sizes.wanted(props) else ""
            if issue:
                self.report({"ERROR"}, issue)
                return {"CANCELLED"}
            if ref.destination_state == "new_mod_required":
                return bpy.ops.xiv_ie.vanilla_mod_name("INVOKE_DEFAULT", name="")
        except ContextValidationError as error:
            self.report({"ERROR"}, str(error))
            return {"CANCELLED"}
        if props.variant_target == MASHUP_TARGET:
            return bpy.ops.xiv_ie.mashup_destination("INVOKE_DEFAULT")
        if props.variant_target == SAVE_NEW_MOD_TARGET:
            return bpy.ops.xiv_ie.save_new_mod_name("INVOKE_DEFAULT", name="")
        self._confirm_unsafe_export = unsafe_export_warning_state(context, blocking=True)
        self._dropped_shape_keys = quick_export_dropped_shape_keys(context)
        self._size_count = sizes.batch_count(props)
        if self._confirm_unsafe_export or self._dropped_shape_keys:
            # invoke_confirm never calls draw(); a props dialog shows the materials and meshes.
            return context.window_manager.invoke_props_dialog(
                self, width=460,
                title="Export Without Mashup?" if self._confirm_unsafe_export else "Export Without Shape Keys?",
                confirm_text="Export Anyway")
        if self._size_count:
            return context.window_manager.invoke_props_dialog(
                self, width=360, title=f"Export {self._size_count} Sizes?", confirm_text="Export")
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        size_count = getattr(self, "_size_count", 0)
        if size_count:
            column = layout.column(align=True)
            for index, line in enumerate(sizes.batch_warning(size_count)):
                column.label(text=line, icon="TIME" if index == 0 else "BLANK1")
            if getattr(self, "_confirm_unsafe_export", False) or getattr(self, "_dropped_shape_keys", []):
                layout.separator()
        if getattr(self, "_confirm_unsafe_export", False):
            missing_materials = material_coverage_missing_materials(
                context, cache_only=True)
            layout.label(text="The output mod is missing files for these materials:", icon="ERROR")
            column = layout.column(align=True)
            for material in missing_materials[:12]:
                column.label(text=material, icon="MATERIAL")
            if len(missing_materials) > 12:
                column.label(text=f"+{len(missing_materials) - 12} more materials", icon="BLANK1")
            layout.label(text=UNSAFE_EXPORT_WARNING, icon="BLANK1")
            layout.label(text="Choose Create Mashup as the target to include them.", icon="BLANK1")
        draw_dropped_shape_keys(layout, getattr(self, "_dropped_shape_keys", []))

    def execute(self, context: Context):
        # A step at a time, Blender drawing between them (steps.start).
        return steps.start(context, instant_export_steps(context), self._done, self._failed, self.report,
                           "Nothing was sent to Penumbra.")

    @staticmethod
    def _done(report, _result) -> None:
        status = get_instant_edit_props().last_status
        report(
            {"WARNING"} if " with warnings:" in status or "could not refresh" in status else {"INFO"},
            status,
        )
        get_export_stats(bpy.context)

    @staticmethod
    def _failed(report, error) -> None:
        get_instant_edit_props().last_status = f"Export failed: {error}"
        report({"ERROR"}, f"Export failed: {error}")


class MashupDestination(Operator):
    bl_idname = "xiv_ie.mashup_destination"
    bl_label = "Create Mashup"
    bl_description = "Combine the visible Contexts and their material and texture dependencies into one mashup"

    destination: EnumProperty(
        name="Destination",
        items=[
            ("ACTIVE_MOD", "New Group", "Add the mashup as a new option group in the selected Context's mod"),
            ("NEW_MOD", "New Mod", "Create a new Penumbra mod and list its required external dependencies"),
        ],
        default="ACTIVE_MOD",
    )  # type: ignore
    name: StringProperty(
        name="Name",
        description="Name of the new option group or Penumbra mod",
        default="Mashup",
        maxlen=120,
    )  # type: ignore
    bundle_external_dependencies: BoolProperty(
        name="Bundle external dependencies",
        description=(
            "Copy eligible materials and textures from non-participating mods into the mashup; "
            "shared body, skin, pube, and piercing materials remain external"
        ),
        default=False,
    )  # type: ignore

    def draw(self, _context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(self, "destination", expand=True)
        layout.prop(self, "name", text="Group Name" if self.destination == "ACTIVE_MOD" else "Mod Name")
        layout.prop(self, "bundle_external_dependencies", text="Bundle Dependencies")
        note = layout.row()
        note.active = False
        note.label(text="Shared skin, pube, and piercing materials stay external.", icon="INFO")
        draw_dropped_shape_keys(layout, getattr(self, "_dropped_shape_keys", []))

    def invoke(self, context: Context, _event):
        try:
            mashup_export_selection(context)
        except Exception as error:
            self.report({"ERROR"}, str(error))
            return {"CANCELLED"}
        self._dropped_shape_keys = quick_export_dropped_shape_keys(context)
        return context.window_manager.invoke_props_dialog(
            self, width=460, title="Create Mashup", confirm_text="Create Mashup")

    def execute(self, context: Context):
        try:
            perform_mashup_export(
                context,
                self.destination,
                self.name,
                bundle_external_dependencies=self.bundle_external_dependencies,
            )
        except Exception as error:
            props = get_instant_edit_props()
            props.last_status = f"Mashup failed: {error}"
            self.report({"ERROR"}, props.last_status)
            return {"CANCELLED"}
        status = get_instant_edit_props().last_status
        self.report({"WARNING"} if "warnings:" in status else {"INFO"}, status)
        get_export_stats(context)
        return {"FINISHED"}


class SaveNewModName(Operator):
    bl_idname = "xiv_ie.save_new_mod_name"
    bl_label = "Save to new mod"
    bl_description = "Name the new Penumbra mashup mod"

    name: StringProperty(name="Mod Name", default="", maxlen=120)  # type: ignore

    def draw(self, _context):
        self.layout.prop(self, "name", text="Mod Name", placeholder="Name of the new mod")
        draw_dropped_shape_keys(self.layout, getattr(self, "_dropped_shape_keys", []))

    def invoke(self, context: Context, _event):
        self._dropped_shape_keys = quick_export_dropped_shape_keys(context)
        return context.window_manager.invoke_props_dialog(
            self, width=460 if self._dropped_shape_keys else 430, title="Save as New Mod", confirm_text="Save")

    def execute(self, context: Context):
        try:
            perform_mashup_export(
                context, "NEW_MOD", self.name, allow_single_context=True)
        except Exception as error:
            props = get_instant_edit_props()
            props.last_status = f"Save to new mod failed: {error}"
            self.report({"ERROR"}, props.last_status)
            return {"CANCELLED"}
        status = get_instant_edit_props().last_status
        self.report({"WARNING"} if "warnings:" in status else {"INFO"}, status)
        get_export_stats(context)
        return {"FINISHED"}


class VanillaModName(Operator):
    bl_idname = "xiv_ie.vanilla_mod_name"
    bl_label = "Create Penumbra Mod"
    bl_description = "Name the new Penumbra mod for this game-data model"

    name: StringProperty(name="Mod Name", default="", maxlen=120)  # type: ignore

    def draw(self, _context):
        self.layout.prop(self, "name", text="Mod Name", placeholder="Name of the new mod")
        draw_dropped_shape_keys(self.layout, getattr(self, "_dropped_shape_keys", []))

    def invoke(self, context: Context, _event):
        self._dropped_shape_keys = quick_export_dropped_shape_keys(context)
        return context.window_manager.invoke_props_dialog(
            self, width=460 if self._dropped_shape_keys else 430, title="Create Penumbra Mod",
            confirm_text="Create Mod")

    def execute(self, context: Context):
        return steps.start(context, instant_export_steps(context, new_mod_name=self.name), QuickExport._done,
                           QuickExport._failed, self.report, "Nothing was sent to Penumbra.")


# ---- Context and mesh-part management operators ----


class ClearInstantEditContexts(Operator):
    bl_idname = "xiv_ie.clear_contexts"
    bl_label = "Clear Contexts"
    bl_description = "Clear all XIV Instant Edit context information without deleting scene objects"

    @classmethod
    def poll(cls, context: Context):
        return context.mode == "OBJECT"

    def invoke(self, context: Context, event):
        count = len(context_collections(context.scene))
        if not count:
            self.report({"INFO"}, "There are no XIV Instant Edit Contexts to clear.")
            return {"CANCELLED"}
        # The plugin revokes the cleared Contexts, which undo cannot bring back.
        return context.window_manager.invoke_confirm(
            self,
            event,
            title="Clear All Contexts?",
            message=(
                f"Forget {count} Context{'s' if count != 1 else ''}? The scene objects stay, "
                "but Quick Export can no longer write them back to their mods. This cannot be undone."
            ),
            confirm_text="Clear Contexts",
            icon="WARNING",
        )

    def execute(self, context: Context):
        collections = context_collections(context.scene)
        from .revocation import queue_context_revocations, schedule_revocations

        try:
            queued = queue_context_revocations(collections)
        except Exception as error:
            self.report({"ERROR"}, f"Contexts were not cleared: could not save revocations: {error}")
            return {"CANCELLED"}
        props = get_instant_edit_props()
        props.export_destination = "NONE"
        props.variant_targets.clear()
        props.variant_targets_context_id = ""
        cleared = clear_context_metadata(context.scene)
        for field, value in {
            "game_path": "",
            "display_name": "",
            "object_index": -1,
            "context_id": "",
            "context_schema": "",
            "context_version": 0,
            "plugin_instance_id": "",
            "capability": "",
            "managed_destination": "",
            "last_export_id": "",
            "variant_group_name": "New Group",
            "last_status": f"XIV Instant Edit contexts cleared; {queued} revocation(s) queued.",
        }.items():
            setattr(props, field, value)
        schedule_revocations()
        self.report({"INFO"}, f"Cleared {cleared} XIV Instant Edit context(s); revocation queued.")
        return {"FINISHED"}


class CopyInstantEditStatus(Operator):
    bl_idname = "xiv_ie.copy_status"
    bl_label = "Copy Full Import Status"
    bl_description = "Copy the complete XIV Instant Edit status message to the clipboard"

    def execute(self, context):
        context.window_manager.clipboard = get_instant_edit_props().last_status
        self.report({"INFO"}, "XIV Instant Edit status copied")
        return {"FINISHED"}


class CopyExportTargetStatus(Operator):
    bl_idname = "xiv_ie.copy_target_status"
    bl_label = "Copy Full Export Target Status"
    bl_description = "Copy the complete Quick Export target selection status to the clipboard"

    status_message: StringProperty(
        name="",
        default="",
        maxlen=8192,
        options={"HIDDEN", "SKIP_SAVE"},
    )  # type: ignore

    def execute(self, context):
        context.window_manager.clipboard = self.status_message
        self.report({"INFO"}, "XIV Instant Edit export target status copied")
        return {"FINISHED"}


def build_export_payload(ref, export_id: str, mdl_path: Path, byte_size: int,
                         sha256: str, props, variant_name: str | None,
                         variant_group_name: str | None = None, variant_target=None,
                         backup_existing: bool | None = None, *,
                          setup_in_penumbra: bool = True,
                         new_mod_name: str | None = None,
                         attribute_tags: tuple[str, ...] = (),
                         attribute_masks: dict[str, int] | None = None,
                         est_entries: list[dict] | None = None) -> dict:
    """Build the versioned Dalamud export envelope.

    ``est_entries`` is the hair EST entry from the meshes' Magic Fit tags: omitted
    (None) the plugin leaves the mod's EST entries alone, empty it takes back the
    entry it set before.
    """
    payload = {
        "schema": "instant-edit.export",
        "version": VERSION,
        "pluginInstanceId": ref.plugin_instance_id,
        "contextId": ref.context_id,
        "exportId": export_id,
        "capability": ref.capability,
        "filePath": str(mdl_path),
        "size": byte_size,
        "sha256": sha256,
        "backupExisting": bool(
            getattr(get_settings(), "backup_models_on_export", False)
            if backup_existing is None else backup_existing
        ),
    }
    payload["setupInPenumbra"] = setup_in_penumbra
    if new_mod_name is not None:
        payload["newModName"] = new_mod_name
    if getattr(props, "create_attribute_groups", False):
        payload["createAttributeGroups"] = True
        payload["attributeTags"] = list(attribute_tags)
        payload["attributeMasks"] = dict(attribute_masks or {})
    if est_entries is not None:
        payload["estEntries"] = [dict(entry) for entry in est_entries]
    if setup_in_penumbra:
        if variant_name is not None:
            payload["variantName"] = variant_name
        payload["variantGroupName"] = variant_group_name
        payload["variantTarget"] = "option" if variant_target and variant_target.kind == "OPTION" else (
            "group" if variant_target and variant_target.kind == "GROUP" else "new_group"
        )
        if variant_target:
            payload["variantTargetId"] = variant_target.selection_id
    return payload


def _plugin_error_from_body(
    body: bytes, status: int, endpoint: str = "/plugin"
) -> PluginResponseError:
    failure = record_remote_failure(
        body,
        status,
        endpoint=endpoint,
        default_operation=_plugin_operation(endpoint),
    )
    return PluginResponseError(
        status, failure["code"], failure["cause"],
        component=failure["component"], operation=failure["operation"],
        stage=failure["stage"], remedy=failure["remedy"],
        diagnostic_id=failure["diagnosticId"])


def _decode_plugin_response(body: bytes, status: int, endpoint: str = "/plugin") -> dict:
    if len(body) > MAX_PLUGIN_RESPONSE_SIZE:
        failure = record_protocol_failure(
            body, status, endpoint=endpoint,
            operation=_plugin_operation(endpoint),
            code="response_too_large",
            cause="The Dalamud plugin returned a response larger than the bridge limit.")
        raise PluginResponseError(
            status, failure["code"], failure["cause"],
            component=failure["component"], operation=failure["operation"],
            stage=failure["stage"], remedy=failure["remedy"],
            diagnostic_id=failure["diagnosticId"])
    try:
        result = json.loads(body.decode("utf-8"))
    except (UnicodeError, json.JSONDecodeError):
        failure = record_protocol_failure(
            body, status, endpoint=endpoint,
            operation=_plugin_operation(endpoint))
        raise PluginResponseError(
            status, failure["code"], failure["cause"],
            component=failure["component"], operation=failure["operation"],
            stage=failure["stage"], remedy=failure["remedy"],
            diagnostic_id=failure["diagnosticId"])
    if not isinstance(result, dict):
        failure = record_protocol_failure(
            body, status, endpoint=endpoint,
            operation=_plugin_operation(endpoint))
        raise PluginResponseError(
            status, failure["code"], failure["cause"],
            component=failure["component"], operation=failure["operation"],
            stage=failure["stage"], remedy=failure["remedy"],
            diagnostic_id=failure["diagnosticId"])
    if not result.get("ok"):
        raise _plugin_error_from_body(json.dumps(result).encode("utf-8"), status, endpoint)
    warnings = result.get("warnings", [])
    if not isinstance(warnings, list) or any(not isinstance(item, str) for item in warnings):
        failure = record_protocol_failure(
            body, status, endpoint=endpoint,
            operation=_plugin_operation(endpoint),
            code="invalid_warning_list",
            cause="The Dalamud plugin returned an invalid warning list.")
        raise PluginResponseError(
            status, failure["code"], failure["cause"],
            component=failure["component"], operation=failure["operation"],
            stage=failure["stage"], remedy=failure["remedy"],
            diagnostic_id=failure["diagnosticId"])
    result["warnings"] = [item[:2048] for item in warnings[:64] if item]
    required_external_mods = result.get("requiredExternalMods", [])
    if (
        not isinstance(required_external_mods, list) or
        any(not isinstance(item, str) for item in required_external_mods)
    ):
        failure = record_protocol_failure(
            body, status, endpoint=endpoint,
            operation=_plugin_operation(endpoint),
            code="invalid_external_mod_list",
            cause="The Dalamud plugin returned an invalid external-mod requirement list.")
        raise PluginResponseError(
            status, failure["code"], failure["cause"],
            component=failure["component"], operation=failure["operation"],
            stage=failure["stage"], remedy=failure["remedy"],
            diagnostic_id=failure["diagnosticId"])
    result["requiredExternalMods"] = [
        item[:160] for item in required_external_mods[:64] if item
    ]
    return result


def plugin_warning_summary(warnings) -> str:
    items = [item[:512] for item in warnings if isinstance(item, str) and item]
    summary = "; ".join(items[:3])
    if len(items) > 3:
        summary += f" (+{len(items) - 3} more)"
    return summary


def _request_export_status(ref, export_id: str) -> tuple[dict | None, bool]:
    """Return (receipt, pending); missing/unreachable receipts return (None, False)."""
    payload = {
        "schema": "instant-edit.export-status",
        "version": 1,
        "pluginInstanceId": ref.plugin_instance_id,
        "contextId": ref.context_id,
        "exportId": export_id,
        "capability": ref.capability,
    }
    try:
        status, body = post_json(
            ref.callback_port, "/export/status", payload,
            timeout=2, max_response_size=MAX_PLUGIN_RESPONSE_SIZE)
        if status == 202:
            result = _decode_plugin_response(body, status, "/export/status")
            return None, result.get("code") == "export_pending"
        if 200 <= status < 300:
            return _decode_plugin_response(body, status, "/export/status"), False
        if status != 404:
            raise _plugin_error_from_body(body, status, "/export/status")
    except PluginResponseError:
        raise
    except PluginResponseTooLarge as error:
        raise _plugin_response_too_large(error, "/export/status") from error
    except (URLError, TimeoutError, OSError, ValueError, UnicodeError):
        pass
    return None, False


def _recover_export_receipt(ref, export_id: str) -> dict | None:
    for attempt in range(EXPORT_STATUS_POLL_ATTEMPTS):
        receipt, pending = _request_export_status(ref, export_id)
        if receipt is not None:
            return receipt
        if not pending:
            return None
        if attempt + 1 < EXPORT_STATUS_POLL_ATTEMPTS:
            time.sleep(0.5)
    return None


def _send_plugin_export_to(ref, payload: dict, endpoint: str) -> dict:
    try:
        status, body = post_json(
            ref.callback_port, endpoint, payload,
            timeout=15, max_response_size=MAX_PLUGIN_RESPONSE_SIZE)
        if not 200 <= status < 300:
            raise _plugin_error_from_body(body, status, endpoint)
        return _decode_plugin_response(body, status, endpoint)
    except PluginResponseTooLarge as error:
        raise _plugin_response_too_large(error, endpoint) from error
    except (URLError, TimeoutError, OSError) as error:
        export_id = str(payload.get("exportId", ""))
        if export_id:
            receipt = _recover_export_receipt(ref, export_id)
            if receipt is not None:
                return receipt
            message = f"plugin response was lost and no receipt was available for export {export_id}"
        else:
            message = "plugin response was lost"
        raise _plugin_transport_error(
            error,
            endpoint,
            f"The {endpoint.strip('/') or 'plugin'} response was lost before Blender received it.",
            f"Retry the operation. If it fails again, review the diagnostic report for {message}.",
        ) from error


def _send_plugin_mashup_plan(
    ref, contributors: list[dict], destination: str, bundle_external_dependencies: bool = False
) -> dict:
    payload = {
        "schema": "instant-edit.mashup-plan",
        "version": 1,
        "pluginInstanceId": ref.plugin_instance_id,
        "contextId": ref.context_id,
        "capability": ref.capability,
        "destination": destination,
        "bundleExternalDependencies": bool(bundle_external_dependencies),
        "contributors": contributors,
    }
    result = _send_plugin_export_to(ref, payload, "/mashup/plan")
    fingerprint = result.get("planFingerprint")
    assignments = result.get("assignments")
    if (
        not isinstance(fingerprint, str) or len(fingerprint) != 64 or
        not all(char in "0123456789abcdefABCDEF" for char in fingerprint) or
        not isinstance(assignments, list)
    ):
        raise ValueError("plugin returned an invalid mashup material plan")
    return result


def _mashup_contributor_payload(refs, materials: dict[str, list[str]]) -> list[dict]:
    return [
        {
            "contextId": item.context_id,
            "capability": item.capability,
            "materials": list(materials[item.context_id]),
        }
        for item in refs
    ]


def _material_coverage_contributor_payload(
    ref,
    refs,
    materials: dict[str, list[str]],
) -> list[dict]:
    """Build the advisory payload without false positives from shared resources.

    The material coverage endpoint is about dependencies that a non-active
    source contributes to the selected output.  A non-active copy of a model
    material already present in the active context cannot replace that active
    material, and body/general materials are intentionally shared across
    contexts.  Exclude both cases from the advisory request while leaving the
    real mashup payload unchanged.
    """
    active_materials = {
        _normalize_mashup_material(material).casefold()
        for material in materials.get(ref.context_id, ())
    }
    contributors = []
    for item in refs:
        if item.context_id == ref.context_id:
            continue
        values = [
            material for material in materials[item.context_id]
            if not _is_general_material(material)
            and _normalize_mashup_material(material).casefold() not in active_materials
        ]
        if not values:
            continue
        contributors.append({
            "contextId": item.context_id,
            "capability": item.capability,
            "materials": values,
        })
    return contributors


def _mashup_assignment_map(plan: dict, materials: dict[str, list[str]]) -> dict[tuple[str, str], str]:
    expected = {
        (context_id, _normalize_mashup_material(material).casefold())
        for context_id, values in materials.items()
        for material in values
    }
    assignments = {}
    for raw in plan["assignments"]:
        if not isinstance(raw, dict):
            raise ValueError("plugin returned an invalid mashup material assignment")
        context_id = raw.get("contextId")
        model_material = raw.get("modelMaterial")
        alias = raw.get("alias")
        if not all(isinstance(value, str) and value for value in (context_id, model_material, alias)):
            raise ValueError("plugin returned an incomplete mashup material assignment")
        key = (context_id, _normalize_mashup_material(model_material).casefold())
        normalized_alias = _normalize_mashup_material(alias)
        if key in assignments or key not in expected:
            raise ValueError("plugin returned an unexpected mashup material assignment")
        assignments[key] = normalized_alias
    if set(assignments) != expected:
        raise ValueError("plugin mashup material plan is incomplete")
    return assignments


def _send_plugin_restore(ref, backup_name: str) -> dict:
    selected = selected_variant_target(get_instant_edit_props())
    backup_target_id = getattr(selected, "backup_target_id", "") or ref.backup_target_id
    payload = {
        "schema": "instant-edit.backup-restore",
        "version": 2,
        "pluginInstanceId": ref.plugin_instance_id,
        "contextId": ref.context_id,
        "capability": ref.capability,
        "backupName": backup_name,
        "backupTargetId": backup_target_id,
    }
    try:
        status, body = post_json(
            ref.callback_port, "/backup/restore", payload,
            timeout=15, max_response_size=MAX_PLUGIN_RESPONSE_SIZE)
        if not 200 <= status < 300:
            raise _plugin_error_from_body(body, status, "/backup/restore")
        return _decode_plugin_response(body, status, "/backup/restore")
    except PluginResponseTooLarge as error:
        raise _plugin_response_too_large(error, "/backup/restore") from error
    except (URLError, TimeoutError, OSError) as error:
        raise _plugin_transport_error(
            error,
            "/backup/restore",
            "The Dalamud plugin could not be reached while restoring the backup.",
            "Start XIV Instant Edit in the game and retry.",
        ) from error


def restore_quick_backup(context: Context, backup_name: str) -> dict:
    """Restore an authorized MDL backup through the plugin and reload Penumbra."""
    ref = export_destination_context(context)
    props = get_instant_edit_props()
    try:
        result = _send_plugin_restore(ref, backup_name)
    except PluginResponseError as error:
        if error.status != 410 and not (error.status == 401 and error.code == "plugin_instance_mismatch"):
            raise
        from .recovery import reattach_collection

        if not reattach_collection(ref.collection, context.scene):
            raise ValueError(f"plugin returned HTTP {error.status} ({error.code}); context recovery failed") from error
        ref = export_destination_context(context)
        result = _send_plugin_restore(ref, backup_name)
    warnings = result.get("warnings", [])
    target = result.get("targetFilePath") or ref.target_file_path
    props.last_status = (
        f"Restored {target} with warnings: {plugin_warning_summary(warnings)}"
        if warnings else f"Restored {target}"
    )
    return result


def _send_plugin_clear(ref) -> dict:
    selected = selected_variant_target(get_instant_edit_props())
    backup_target_id = getattr(selected, "backup_target_id", "") or ref.backup_target_id
    payload = {
        "schema": "instant-edit.backup-clear",
        "version": 1,
        "pluginInstanceId": ref.plugin_instance_id,
        "contextId": ref.context_id,
        "capability": ref.capability,
        "backupTargetId": backup_target_id,
    }
    try:
        status, body = post_json(
            ref.callback_port, "/backup/clear", payload,
            timeout=15, max_response_size=MAX_PLUGIN_RESPONSE_SIZE)
        if not 200 <= status < 300:
            raise _plugin_error_from_body(body, status, "/backup/clear")
        return _decode_plugin_response(body, status, "/backup/clear")
    except PluginResponseTooLarge as error:
        raise _plugin_response_too_large(error, "/backup/clear") from error
    except (URLError, TimeoutError, OSError) as error:
        raise _plugin_transport_error(
            error,
            "/backup/clear",
            "The Dalamud plugin could not be reached while clearing the backups.",
            "Start XIV Instant Edit in the game and retry.",
        ) from error


def clear_quick_backups(context: Context) -> dict:
    """Delete the Quick Export target's managed backups through the plugin."""
    ref = export_destination_context(context)
    try:
        return _send_plugin_clear(ref)
    except PluginResponseError as error:
        if error.status != 410 and not (error.status == 401 and error.code == "plugin_instance_mismatch"):
            raise
        from .recovery import reattach_collection

        if not reattach_collection(ref.collection, context.scene):
            raise ValueError(f"plugin returned HTTP {error.status} ({error.code}); context recovery failed") from error
        return _send_plugin_clear(export_destination_context(context))


# ---- Export destination resolution and attribute-group detection ----


def export_destination_context(
    context: Context,
    destination: str | None = None,
    *,
    persist: bool = True,
):
    """Resolve the selected export context.

    Blender does not allow ID-property writes while a panel is being drawn.
    Callers that only need to render the current state can disable persistence
    while retaining the legacy single-context resolution behavior.
    """
    props = get_instant_edit_props()
    destination = (
        destination
        or getattr(props, "export_destination", NO_EXPORT_CONTEXT)
        or NO_EXPORT_CONTEXT
    )
    if destination in {"ACTIVE", NO_EXPORT_CONTEXT}:
        # Saved scenes from before the explicit selector used ACTIVE. A lone
        # destination is still displayed and stored as a concrete context ID;
        # multiple destinations always require an explicit user choice.
        refs = _valid_export_contexts(context)
        if len(refs) == 1:
            destination = refs[0].context_id
            if persist:
                props.export_destination = destination
        elif destination == "ACTIVE":
            if persist:
                props.export_destination = NO_EXPORT_CONTEXT
    if destination == NO_EXPORT_CONTEXT:
        raise ContextValidationError("Select a Context before exporting or restoring.")
    return validate_context(destination, context.scene)


def export_objects_for_scope(ref, scope: str) -> list:
    """Return the mesh objects selected by a shared Quick/Simple export scope: its visible meshes,
    with the parts of their models a character send imported hidden because the game didn't draw
    them (see character.with_game_hidden_parts), so a model always exports whole."""
    objects = character_send.with_game_hidden_parts(bpy.context.scene, visible_meshobj())
    if scope == "VISIBLE_NO_MANNEQUIN":
        excluded = getattr(get_instant_edit_props(), "export_excluded_mesh", None)
        if excluded is not None:
            return [obj for obj in objects if obj.as_pointer() != excluded.as_pointer()]
        return objects
    if scope == "CURRENT_COLLECTION":
        if ref is None:
            raise ContextValidationError(
                "Select a Context before exporting the XIV Instant Edit Collection."
            )
        collection_objects = {obj.as_pointer() for obj in ref.collection.objects}
        return [obj for obj in objects if obj.as_pointer() in collection_objects]
    return objects


def detected_attribute_group_tags(context: Context) -> tuple[str, ...]:
    """Return exportable part/custom tags for the current Quick Export scope."""
    ref = export_destination_context(context, persist=False)
    objects = export_objects_for_scope(
        ref, getattr(get_instant_edit_props(), "export_scope", "VISIBLE"))
    if not objects:
        return ()
    tags, _masks = attribute_group_data(
        objects, use_lods=get_settings().use_lods)
    return tags


def raise_unless_exportable(export_objects, game_path: str, *, race_model: bool = False) -> int | None:
    """Refuse meshes the game cannot use: faces must be triangles and meshes need bone weights.
    Meshes shaped for another race than the model at ``game_path`` is for are refused too, unless they
    go out as their race's own model (``race_model``); then that race is returned."""
    race = None
    if race_model:
        race, refusal = racial_scaling.race_model(export_objects, game_path)
    else:
        refusal = racial_scaling.mismatch_refusal(export_objects, game_path)
    if refusal:
        raise ValueError(refusal)
    flush_edit_mode(export_objects)
    not_triangulated = check_triangulation(export_objects)
    if not_triangulated:
        raise ValueError("Not Triangulated: " + ", ".join(not_triangulated) + ".")
    unweighted = check_weights(export_objects)
    if unweighted:
        raise ValueError(
            "No bone weights: " + ", ".join(unweighted)
            + ". Weight them to the armature's bones before exporting.")
    uv_problems = check_uv_layers(export_objects)
    if uv_problems:
        raise ValueError(" ".join(uv_problems))
    return race


# ---- Mashup export execution ----


@contextmanager
def _exporting_as_mdl():
    """Make the scene's export format MDL for one export, then restore it.

    Quick Export and mashups always write MDL, but SceneHandler reads the
    format from the scene settings. The setting also belongs to Simple Export,
    so the user's choice must survive.
    """
    settings = get_settings()
    previous = settings.model_format
    settings.model_format = "MDL"
    try:
        yield
    finally:
        settings.model_format = previous


def perform_mashup_export(
    context: Context,
    destination: str,
    name: str,
    *,
    allow_single_context: bool = False,
    bundle_external_dependencies: bool = False,
) -> Path:
    name = (name or "").strip()
    if not name or len(name) > 120 or any(ord(char) < 32 for char in name):
        raise ValueError("Enter a valid mashup or mod name.")
    if destination not in {"ACTIVE_MOD", "NEW_MOD"}:
        raise ValueError("Invalid mashup destination.")
    if destination == "NEW_MOD" and (
        name != name.strip() or name in {".", ".."} or name.endswith(".") or
        any(char in INVALID_VARIANT_CHARS for char in name)
    ):
        raise ValueError("Mod name contains characters that cannot be used in a folder name.")
    if sizes.wanted():
        raise ValueError("Sizes can't go into a mashup or a new mod.")

    ref = export_destination_context(context)
    minimum_contexts = 1 if allow_single_context else 2
    export_objects, refs, materials, object_contexts = mashup_export_selection(
        context, ref, minimum_contexts=minimum_contexts)
    export_groups = group_mesh_objects(export_objects)
    recognized = {obj for group in export_groups for obj in group.objects}
    unrecognized = [obj.name for obj in export_objects if obj not in recognized]
    if unrecognized:
        raise ValueError(
            "Visible mesh names must use 'group.part Name' or 'Name group.part': "
            + ", ".join(unrecognized))
    raise_unless_exportable(export_objects, ref.source_game_path)
    attribute_tags, attribute_masks = (
        attribute_group_data(export_objects, use_lods=get_settings().use_lods)
        if getattr(get_instant_edit_props(), "create_attribute_groups", False)
        else ((), {})
    )
    est_entries, est_issue = hair_skeleton_tags(export_objects)

    contributors = _mashup_contributor_payload(refs, materials)
    plugin_destination = "active_mod" if destination == "ACTIVE_MOD" else "new_mod"
    try:
        plan = _send_plugin_mashup_plan(
            ref, contributors, plugin_destination, bundle_external_dependencies)
    except PluginResponseError as error:
        if error.status != 410 and not (
            error.status == 401 and error.code == "plugin_instance_mismatch"
        ):
            raise
        from .recovery import reattach_collection

        if not all(reattach_collection(item.collection, context.scene) for item in refs):
            raise ValueError(
                f"plugin returned HTTP {error.status} ({error.code}); mashup context recovery failed"
            ) from error
        ref = export_destination_context(context)
        export_objects, refs, materials, object_contexts = mashup_export_selection(
            context, ref, minimum_contexts=minimum_contexts)
        contributors = _mashup_contributor_payload(refs, materials)
        plan = _send_plugin_mashup_plan(
            ref, contributors, plugin_destination, bundle_external_dependencies)
        if getattr(get_instant_edit_props(), "create_attribute_groups", False):
            attribute_tags, attribute_masks = attribute_group_data(
                export_objects, use_lods=get_settings().use_lods)
        est_entries, est_issue = hair_skeleton_tags(export_objects)
    assignments = _mashup_assignment_map(plan, materials)

    export_id = uuid.uuid4().hex
    temp_dir = create_job("exports", export_id)
    mdl_path = temp_dir / f"mashup_{export_id}.mdl"
    saved_materials = []
    persist_active_assignments = False
    try:
        for obj in export_objects:
            context_id, material = object_contexts[obj.as_pointer()]
            alias = assignments[(context_id, material.casefold())]
            properties = []
            for property_name in ("xiv_material", "instant_edit_xiv_material"):
                existed = property_name in obj
                properties.append((property_name, existed, obj.get(property_name)))
                if property_name == "xiv_material" or existed:
                    obj[property_name] = alias
            saved_materials.append((obj, properties))

        with _exporting_as_mdl():
            export_result(mdl_path.with_suffix(""), "MDL", export_objects=export_objects)
        if not mdl_path.is_file():
            raise ValueError("Mashup export produced no .mdl file.")
        data = mdl_path.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        payload = {
            "schema": "instant-edit.mashup-export",
            "version": 2,
            "pluginInstanceId": ref.plugin_instance_id,
            "contextId": ref.context_id,
            "exportId": export_id,
            "capability": ref.capability,
            "filePath": str(mdl_path),
            "size": len(data),
            "sha256": digest,
            "destination": plugin_destination,
            "bundleExternalDependencies": bool(bundle_external_dependencies),
            "name": name,
            "planFingerprint": plan["planFingerprint"],
            "contributors": contributors,
        }
        if getattr(get_instant_edit_props(), "create_attribute_groups", False):
            payload["createAttributeGroups"] = True
            payload["attributeTags"] = list(attribute_tags)
            payload["attributeMasks"] = dict(attribute_masks)
        if est_entries is not None:
            payload["estEntries"] = [dict(entry) for entry in est_entries]
        try:
            result = _send_plugin_export_to(ref, payload, "/mashup/export")
        except PluginResponseError as error:
            if error.status != 410 and not (
                error.status == 401 and error.code == "plugin_instance_mismatch"
            ):
                raise
            from .recovery import reattach_collection

            if not all(reattach_collection(item.collection, context.scene) for item in refs):
                raise ValueError(
                    f"plugin returned HTTP {error.status} ({error.code}); mashup context recovery failed"
                ) from error
            ref = export_destination_context(context)
            _objects, refs, materials, _object_contexts = mashup_export_selection(
                context, ref, minimum_contexts=minimum_contexts)
            payload["pluginInstanceId"] = ref.plugin_instance_id
            payload["capability"] = ref.capability
            payload["contributors"] = _mashup_contributor_payload(refs, materials)
            result = _send_plugin_export_to(ref, payload, "/mashup/export")
        warnings = ([est_issue] if est_issue else []) + list(result.get("warnings", []))
        target = result.get("targetFilePath") or ref.target_file_path
        destination_name = result.get("destinationName") or name
        handoff_warnings = []
        if destination == "ACTIVE_MOD":
            persist_active_assignments = True
            try:
                refresh_variant_targets(
                    context,
                    select_group_name=destination_name,
                    select_option_name=destination_name,
                )
                selected = selected_variant_target(get_instant_edit_props())
                if (
                    selected is None
                    or selected.kind != "OPTION"
                    or selected.group_name.casefold() != destination_name.casefold()
                    or selected.option_name.casefold() != destination_name.casefold()
                ):
                    raise ValueError(
                        f'Penumbra did not return the new mashup target "{destination_name}"'
                    )
            except Exception as error:
                handoff_warnings.append(
                    f"Created the mashup, but the new Penumbra target could not be selected: {error}"
                )
        else:
            output_context = result.get("context")
            if not isinstance(output_context, dict):
                handoff_warnings.append(
                    "Created the mashup mod, but the plugin did not return its Blender export context."
                )
            else:
                try:
                    output_ref, _created_objects = _create_mashup_output_context(
                        context,
                        output_context,
                        str(target),
                        export_objects,
                        object_contexts,
                        assignments,
                    )
                    props = get_instant_edit_props()
                    # The output collection is the complete mashup. Keep the
                    # original contributor collections available without
                    # exporting both the sources and their output copies.
                    props.export_scope = "CURRENT_COLLECTION"
                    props.export_destination = output_ref.context_id
                    try:
                        refresh_variant_targets(context)
                    except Exception as error:
                        handoff_warnings.append(
                            f"Selected the mashup context, but its Penumbra targets could not refresh: {error}"
                        )
                except Exception as error:
                    handoff_warnings.append(
                        f"Created the mashup mod, but its Blender export context could not be created: {error}"
                    )
        if handoff_warnings:
            warnings = list(warnings) + handoff_warnings
        get_instant_edit_props().last_export_id = export_id
        get_instant_edit_props().last_status = (
            f"Created mashup {destination_name} at {target} with warnings: "
            f"{plugin_warning_summary(warnings)}"
            if warnings else f"Created mashup {destination_name} at {target}"
        )
        # The mashup just bundled the contributing contexts' materials into
        # the target mod, so any cached "missing material" answer for this
        # composition now predates the write. Drop it so the next readiness
        # check re-probes the plugin instead of repeating the stale warning.
        reset_material_coverage_state()
        return mdl_path
    finally:
        for obj, properties in reversed(saved_materials):
            if obj.name not in bpy.data.objects:
                continue
            for property_name, existed, previous in properties:
                if existed:
                    obj[property_name] = previous
                else:
                    obj.pop(property_name, None)
        if persist_active_assignments:
            _persist_mashup_assignments(export_objects, object_contexts, assignments, ref.context_id)
        try:
            finish_job(temp_dir)
        except OSError as error:
            print(f"XIV Instant Edit: could not remove mashup export cache job: {error}")


# ---- Instant Export execution ----


def perform_instant_export(
    context: Context,
    destination: str | None = None,
    new_mod_name: str | None = None,
) -> Path:
    """Export one validated context through its authenticated plugin route."""
    return steps.run(instant_export_steps(context, destination, new_mod_name))


def instant_export_steps(
    context: Context,
    destination: str | None = None,
    new_mod_name: str | None = None,
):
    """perform_instant_export's work as steps (see steps.start): the model is written, then sent
    with the plugin's answer awaited on a worker thread; returns the model's path. ``context`` is
    only read before the first step: later steps may run from a modal operator, after the operator
    that started them is gone."""
    ref = export_destination_context(context, destination)
    props = get_instant_edit_props()
    if sizes.wanted(props):
        return (yield from sizes_export_steps(context, ref))
    pending = ref.destination_state == "new_mod_required"
    if pending:
        name = (new_mod_name or "").strip()
        if not name:
            raise ValueError("Enter a name for the new Penumbra mod.")
        if name in {".", ".."} or name.endswith(".") or any(char in INVALID_VARIANT_CHARS for char in name):
            raise ValueError("Mod name contains characters that cannot be used in a folder name.")
        new_mod_name = name
    elif new_mod_name is not None:
        raise ValueError("This context already has a Penumbra destination.")
    if not pending and props.variant_target == MASHUP_TARGET:
        raise ValueError("Use Quick Export to choose the mashup destination and name.")
    if wants_race_model(props, ref, export_objects_for_scope(ref, getattr(props, "export_scope", "VISIBLE"))):
        return (yield from race_export_steps(context, ref, new_mod_name))
    in_place = not pending and props.variant_target == IN_PLACE_TARGET
    variant_target = None if pending or in_place else selected_variant_target(props)
    if variant_target is not None and props.variant_targets_context_id != ref.context_id:
        raise ValueError("Refresh Penumbra targets after changing Context.")
    overwrite_existing_option = variant_target is not None and variant_target.kind == "OPTION"
    variant_name = (
        validate_variant_name(ref.source_game_path, props.variant_name)
        if not pending and not in_place and not overwrite_existing_option else None
    )
    variant_group_name = (
        normalise_variant_group_name(
            variant_target.group_name if variant_target is not None and variant_target.kind == "GROUP"
            else props.variant_group_name)
        if not pending and not in_place and not overwrite_existing_option
        else None
    )
    export_objects = export_objects_for_scope(ref, getattr(props, "export_scope", "VISIBLE"))
    if not export_objects:
        raise ValueError("No visible mesh objects to export.")
    export_groups = group_mesh_objects(export_objects)
    recognized = {obj for group in export_groups for obj in group.objects}
    unrecognized = [obj.name for obj in export_objects if obj not in recognized]
    if unrecognized:
        raise ValueError(
            "Visible mesh names must use 'group.part Name' or 'Name group.part': "
            + ", ".join(unrecognized)
        )
    raise_unless_exportable(export_objects, ref.source_game_path)
    attribute_tags, attribute_masks = (
        attribute_group_data(export_objects, use_lods=get_settings().use_lods)
        if getattr(props, "create_attribute_groups", False)
        else ((), {})
    )
    est_entries, est_issue = hair_skeleton_tags(export_objects)

    export_id = uuid.uuid4().hex
    temp_dir = create_job("exports", export_id)
    mdl_path = temp_dir / f"model_{export_id}.mdl"
    try:
        yield steps.Step("Exporting the model.", 0, 2)
        saved_materials = _use_mashup_source_materials(export_objects, ref.context_id)
        try:
            with _exporting_as_mdl():
                export_result(mdl_path.with_suffix(""), "MDL", export_objects=export_objects)
        finally:
            _restore_object_materials(saved_materials)
        if not mdl_path.is_file():
            raise ValueError("Export produced no .mdl file.")

        byte_size, digest = _file_digest(mdl_path)

        # These are the only fields sent in the body. Port is routing only.
        def payload(current_ref):
            return build_export_payload(
                current_ref,
                export_id,
                mdl_path,
                byte_size,
                digest,
                props,
                variant_name,
                variant_group_name,
                variant_target,
                backup_existing=False if pending else None,
                setup_in_penumbra=not pending and not in_place,
                new_mod_name=new_mod_name,
                attribute_tags=attribute_tags,
                attribute_masks=attribute_masks,
                est_entries=est_entries,
            )

        result, ref = yield from _send_with_reattach(ref, payload, "/export", steps.Step("Sending to Penumbra.", 1, 2))
        context = bpy.context
        props.last_export_id = export_id
        ref = _apply_promoted_context(context, ref, result)
        target_file_path = Path(result.get("targetFilePath") or ref.target_file_path)
        if variant_name is not None and not result.get("targetFilePath"):
            target_file_path = target_file_path.with_name(f"{variant_name}.mdl")
        setup_status = (
            " and created its Penumbra mod" if pending
            else " and set up in Penumbra" if variant_name is not None
            else ""
        )
        group_status = "; ".join(
            f"{group.mesh_index}.({','.join(str(part) for part in group.parts)})"
            for group in export_groups
        )
        warnings = ([est_issue] if est_issue else []) + list(result.get("warnings", []))
        props.last_status = (
            f"Exported {group_status} to {target_file_path}{setup_status} with warnings: "
            f"{plugin_warning_summary(warnings)}"
            if warnings else f"Exported {group_status} to {target_file_path}{setup_status}"
        )
        if pending:
            # A newly created Penumbra destination must not preserve the old
            # Context's target-cache identity.
            props.variant_targets_context_id = ""
        refresh_error = refresh_variant_targets_after_operation(
            context,
            select_group_name=variant_group_name if variant_name is not None else None,
            select_option_name=variant_name if variant_name is not None else None,
        )
        if refresh_error is not None:
            # The model and Penumbra setup have already completed. Leave the
            # target tree recoverable through its manual refresh button.
            props.last_status += f"; Penumbra targets could not refresh: {refresh_error}"
        return mdl_path
    finally:
        try:
            finish_job(temp_dir)
        except OSError as error:
            print(f"XIV Instant Edit: could not remove export cache job: {error}")


def _send_with_reattach(ref, payload_for, endpoint: str, step: steps.Step):
    """Send an export to the plugin, awaiting its answer on a worker thread while the export shows
    ``step`` (steps.in_background); when a saved scene outlived the runtime context or the plugin
    instance, reattach once and send again with the plugin-issued capability and instance id.
    Returns (the plugin's answer, the Context it went out with)."""
    try:
        send = partial(_send_plugin_export_to, ref, payload_for(ref), endpoint)
        return (yield from steps.in_background(send, step)), ref
    except PluginResponseError as error:
        if error.status != 410 and not (
            error.status == 401 and error.code == "plugin_instance_mismatch"
        ):
            raise
        from .recovery import reattach_collection

        scene = bpy.context.scene
        if not reattach_collection(ref.collection, scene):
            raise ValueError(
                f"plugin returned HTTP {error.status} ({error.code}); context recovery failed"
            ) from error
        ref = validate_context(ref.context_id, scene)
        send = partial(_send_plugin_export_to, ref, payload_for(ref), endpoint)
        return (yield from steps.in_background(send, step)), ref


def _apply_promoted_context(context: Context, ref, result: dict):
    """Take on the Context the plugin promoted to the mod a game model's first export created; returns
    the Context to carry on with."""
    promoted = result.get("context")
    if promoted is None:
        return ref
    if not isinstance(promoted, dict):
        raise ValueError("plugin returned an invalid promoted context")
    apply_authoritative_context(ref.collection, promoted)
    ref = validate_context(ref.context_id, context.scene)
    props = get_instant_edit_props()
    props.context_version = int(promoted.get("version", VERSION))
    props.plugin_instance_id = ref.plugin_instance_id
    props.capability = ref.capability
    props.managed_destination = ref.managed_destination
    return ref


def build_race_payload(ref, export_id: str, mdl_path: Path, byte_size: int, sha256: str, props, race: int, *,
                       new_mod_name: str | None = None,
                       attribute_tags: tuple[str, ...] = (),
                       attribute_masks: dict[str, int] | None = None,
                       est_entries: list[dict] | None = None) -> dict:
    """Build the plugin's request to write the meshes as ``race``'s own copy of the model (see
    race_export_steps); ``new_mod_name`` names the mod a game model's first export creates."""
    payload = {
        "schema": "instant-edit.export-race",
        "version": 1,
        "pluginInstanceId": ref.plugin_instance_id,
        "contextId": ref.context_id,
        "exportId": export_id,
        "capability": ref.capability,
        "race": f"c{race:04d}",
        "filePath": str(mdl_path),
        "size": byte_size,
        "sha256": sha256,
        "backupExisting": new_mod_name is None and bool(getattr(get_settings(), "backup_models_on_export", False)),
    }
    if new_mod_name is not None:
        payload["newModName"] = new_mod_name
    if getattr(props, "create_attribute_groups", False):
        payload["createAttributeGroups"] = True
        payload["attributeTags"] = list(attribute_tags)
        payload["attributeMasks"] = dict(attribute_masks or {})
    if est_entries is not None:
        payload["estEntries"] = [dict(entry) for entry in est_entries]
    return payload


def race_export_steps(context: Context, ref, new_mod_name: str | None = None):
    """Quick Export meshes shaped for another race as that race's own copy of the model: the plugin
    writes it next to the imported file (c0801e6000_top.mdl), maps it beside the original and sets the
    EQDP entry that makes the race load it. A game model's first export creates its mod with it.
    Steps, as in instant_export_steps."""
    props = get_instant_edit_props()
    export_objects = export_objects_for_scope(ref, getattr(props, "export_scope", "VISIBLE"))
    if not export_objects:
        raise ValueError("No visible mesh objects to export.")
    export_groups = group_mesh_objects(export_objects)
    recognized = {obj for group in export_groups for obj in group.objects}
    unrecognized = [obj.name for obj in export_objects if obj not in recognized]
    if unrecognized:
        raise ValueError(
            "Visible mesh names must use 'group.part Name' or 'Name group.part': "
            + ", ".join(unrecognized)
        )
    race = raise_unless_exportable(export_objects, ref.source_game_path, race_model=True)
    attribute_tags, attribute_masks = (
        attribute_group_data(export_objects, use_lods=get_settings().use_lods)
        if getattr(props, "create_attribute_groups", False)
        else ((), {})
    )
    est_entries, est_issue = hair_skeleton_tags(export_objects)
    pending = ref.destination_state == "new_mod_required"

    export_id = uuid.uuid4().hex
    temp_dir = create_job("exports", export_id)
    mdl_path = temp_dir / f"model_{export_id}.mdl"
    try:
        yield steps.Step("Exporting the model.", 0, 2)
        saved_materials = _use_mashup_source_materials(export_objects, ref.context_id)
        try:
            with _exporting_as_mdl():
                export_result(mdl_path.with_suffix(""), "MDL", export_objects=export_objects)
        finally:
            _restore_object_materials(saved_materials)
        if not mdl_path.is_file():
            raise ValueError("Export produced no .mdl file.")
        byte_size, digest = _file_digest(mdl_path)

        def payload(current_ref):
            return build_race_payload(
                current_ref, export_id, mdl_path, byte_size, digest, props, race,
                new_mod_name=new_mod_name if pending else None, attribute_tags=attribute_tags,
                attribute_masks=attribute_masks, est_entries=est_entries)

        result, ref = yield from _send_with_reattach(
            ref, payload, "/export/race", steps.Step("Sending to Penumbra.", 1, 2))
        context = bpy.context
        props.last_export_id = export_id
        ref = _apply_promoted_context(context, ref, result)
        target_file_path = result.get("targetFilePath") or racial_scaling.race_model_path(ref.source_game_path, race)
        group_status = "; ".join(
            f"{group.mesh_index}.({','.join(str(part) for part in group.parts)})"
            for group in export_groups
        )
        status = f"Exported {group_status} to {target_file_path} as the c{race:04d} model" + (
            " and created its Penumbra mod" if pending else "")
        warnings = ([est_issue] if est_issue else []) + list(result.get("warnings", []))
        props.last_status = (
            f"{status} with warnings: {plugin_warning_summary(warnings)}" if warnings else status
        )
        if pending:
            # A newly created Penumbra destination must not preserve the old Context's target-cache identity.
            props.variant_targets_context_id = ""
        refresh_error = refresh_variant_targets_after_operation(context)
        if refresh_error is not None:
            props.last_status += f"; Penumbra targets could not refresh: {refresh_error}"
        return mdl_path
    finally:
        try:
            finish_job(temp_dir)
        except OSError as error:
            print(f"XIV Instant Edit: could not remove export cache job: {error}")


def _file_digest(path: Path) -> tuple[int, str]:
    """The size and SHA-256 of an exported file, which the plugin checks."""
    digest = hashlib.sha256()
    byte_size = 0
    with path.open("rb") as exported:
        for chunk in iter(lambda: exported.read(1024 * 1024), b""):
            byte_size += len(chunk)
            digest.update(chunk)
    return byte_size, digest.hexdigest()


# ---- Export at Magic Fit's sizes ----


def _sizes_target(props, ref) -> tuple[str, str | None]:
    """The option group a Quick Export at Magic Fit's sizes goes into: (its name, its target ID, None
    for a new group). A selected option stands for its group."""
    issue = sizes_export_issue(props, ref)
    if issue:
        raise ValueError(issue)
    if props.variant_target == "NEW_GROUP":
        return normalise_variant_group_name(props.variant_group_name), None
    target = selected_variant_target(props)
    if target is None or props.variant_targets_context_id != ref.context_id:
        raise ValueError("Refresh Penumbra targets after changing Context.")
    if target.kind == "GROUP":
        return target.group_name, target.selection_id
    parts = target.selection_id.split(":")
    if target.kind != "OPTION" or len(parts) != 3 or parts[0] != "option":
        raise ValueError("The selected Penumbra target is invalid; refresh targets.")
    return target.group_name, f"group:{parts[1]}"


def build_sizes_payload(ref, export_id: str, files: list[dict], default_size: str, props, group_name: str,
                        group_id: str | None, *, attribute_tags: tuple[str, ...] = (),
                        attribute_masks: dict[str, int] | None = None,
                        est_entries: list[dict] | None = None) -> dict:
    """Build the plugin's request for a Quick Export at Magic Fit's sizes: each size's model (``files``:
    name, filePath, size, sha256) for an option of one group, as build_export_payload does for one model."""
    payload = {
        "schema": "instant-edit.export-sizes",
        "version": 1,
        "pluginInstanceId": ref.plugin_instance_id,
        "contextId": ref.context_id,
        "exportId": export_id,
        "capability": ref.capability,
        "variantTarget": "group" if group_id else "new_group",
        "defaultSize": default_size,
        "sizes": [dict(file) for file in files],
        "backupExisting": bool(getattr(get_settings(), "backup_models_on_export", False)),
    }
    if group_id:
        payload["variantTargetId"] = group_id
    else:
        payload["variantGroupName"] = group_name
    if getattr(props, "create_attribute_groups", False):
        payload["createAttributeGroups"] = True
        payload["attributeTags"] = list(attribute_tags)
        payload["attributeMasks"] = dict(attribute_masks or {})
    if est_entries is not None:
        payload["estEntries"] = [dict(entry) for entry in est_entries]
    return payload


def sizes_export_steps(context: Context, ref):
    """Quick Export at each size picked in Magic Fit's Resize panel (see sizes), every size an option
    of one Penumbra group, as steps (see sizes.export_steps): a size at a time, then sending them, the
    plugin getting all of them in one request; returns the model's path. ``context`` is only read
    before the first step: later steps may run from a modal operator, after the operator that
    started them is gone."""
    props = get_instant_edit_props()
    group_name, group_id = _sizes_target(props, ref)
    export_objects = export_objects_for_scope(ref, getattr(props, "export_scope", "VISIBLE"))
    if not export_objects:
        raise ValueError("No visible mesh objects to export.")
    export_groups = group_mesh_objects(export_objects)
    recognized = {obj for group in export_groups for obj in group.objects}
    unrecognized = [obj.name for obj in export_objects if obj not in recognized]
    if unrecognized:
        raise ValueError(
            "Visible mesh names must use 'group.part Name' or 'Name group.part': "
            + ", ".join(unrecognized)
        )
    raise_unless_exportable(export_objects, ref.source_game_path)
    attribute_tags, attribute_masks = (
        attribute_group_data(export_objects, use_lods=get_settings().use_lods)
        if getattr(props, "create_attribute_groups", False)
        else ((), {})
    )
    est_entries, est_issue = hair_skeleton_tags(export_objects)

    export_id = uuid.uuid4().hex
    temp_dir = create_job("exports", export_id)
    try:
        files = []
        exports = None

        def session():
            nonlocal exports
            exports = ShapeExports(export_objects, "MDL")
            return exports

        def export(_sized, index, name):
            mdl_path = temp_dir / f"size_{index}.mdl"
            exports.write(mdl_path.with_suffix(""))
            if not mdl_path.is_file():
                raise ValueError(f"Export produced no .mdl file for {name}.")
            byte_size, digest = _file_digest(mdl_path)
            files.append({"name": name, "filePath": str(mdl_path), "size": byte_size, "sha256": digest})

        saved_materials = _use_mashup_source_materials(export_objects, ref.context_id)
        try:
            with _exporting_as_mdl():
                results = yield from sizes.export_steps(export_objects, export, session)
        finally:
            _restore_object_materials(saved_materials)
        names = [file["name"] for file in files]
        default_size = sizes.default_name(results, names)

        def payload(current_ref):
            return build_sizes_payload(
                current_ref, export_id, files, default_size, props, group_name, group_id,
                attribute_tags=attribute_tags, attribute_masks=attribute_masks, est_entries=est_entries)

        result, ref = yield from _send_with_reattach(
            ref, payload, "/export/sizes",
            sizes.Step(len(results), len(results), "", "Sending the sizes to Penumbra"))
        context = bpy.context
        props.last_export_id = export_id
        group = result.get("destinationName") or group_name
        status = f"Exported {len(results)} sizes to {group}: {', '.join(names)}"
        warnings = ([est_issue] if est_issue else []) + list(result.get("warnings", []))
        props.last_status = (
            f"{status} with warnings: {plugin_warning_summary(warnings)}" if warnings else status
        )
        resize_notes = sizes.notes(results)
        if resize_notes:
            props.last_status += ". " + " ".join(resize_notes)
        refresh_error = refresh_variant_targets_after_operation(
            context, select_group_name=group, select_option_name=default_size)
        if refresh_error is not None:
            props.last_status += f"; Penumbra targets could not refresh: {refresh_error}"
        return Path(result.get("targetFilePath") or ref.target_file_path)
    finally:
        try:
            finish_job(temp_dir)
        except OSError as error:
            print(f"XIV Instant Edit: could not remove export cache job: {error}")


CLASSES = [
    InstantImport,
    RefreshVariantTargets,
    SelectVariantTarget,
    SelectExportContext,
    OpenContextFolder,
    QuickExport,
    steps.RunExportSteps,
    MashupDestination,
    SaveNewModName,
    VanillaModName,
    ClearInstantEditContexts,
    CopyInstantEditStatus,
    CopyExportTargetStatus,
]
