# Modified for XIV Instant Edit, 2026.
import bpy
from bpy.app.handlers import persistent

from .props  import set_addon_properties, remove_addon_properties, get_instant_edit_props
from .server import (LISTENER_RETRY_SECONDS, LISTENER_UNAVAILABLE, get_server_error,
                     poll_import_queue, poll_listener, start_server, stop_server)
from .recovery import cancel_recovery, schedule_recovery
from .revocation import cancel_revocations, schedule_revocations


_visibility_check_pending = False
_last_visible_context_ids = None


@persistent
def _prepare_for_scene_load(_dummy) -> None:
    """Invalidate work before Blender discards nonpersistent timers and scene IDs."""
    global _visibility_check_pending, _last_visible_context_ids
    from .ops import reset_material_coverage_state

    cancel_recovery()
    cancel_revocations()
    reset_material_coverage_state()
    if bpy.app.timers.is_registered(_run_visibility_check):
        bpy.app.timers.unregister(_run_visibility_check)
    _visibility_check_pending = False
    _last_visible_context_ids = None


@persistent
def _recover_after_scene_load(_dummy) -> None:
    global _last_visible_context_ids
    from .ops import reset_material_coverage_state

    _last_visible_context_ids = None
    reset_material_coverage_state()
    schedule_revocations()
    schedule_recovery()


def _switch_hidden_export_context() -> None:
    """Keep the selector on a visible context when visibility changes."""
    global _last_visible_context_ids
    from .context import visible_collections_in_view_layer, context_collections, context_id_for_object, _value
    from .props import NO_EXPORT_CONTEXT

    scene = getattr(bpy.context, "scene", None)
    view_layer = getattr(bpy.context, "view_layer", None)
    if scene is None or view_layer is None:
        return
    collections = sorted(
        context_collections(scene),
        key=lambda value: (
            str(_value(value, "source_game_path", "")).casefold(),
            str(_value(value, "context_id", "")).casefold(),
        ),
    )
    # Walk the view layer's layer-collection tree once for every context
    # collection here, instead of once per collection - this handler runs on
    # every depsgraph update, so a per-collection tree walk noticeably added
    # up during continuous viewport interaction (dragging, painting, sculpting).
    visible_set = visible_collections_in_view_layer(collections, view_layer)
    visible = [value for value in collections if value in visible_set]
    visible_ids = {
        str(_value(value, "context_id", "")) for value in visible
    }
    previous_visible_context_ids = _last_visible_context_ids
    _last_visible_context_ids = frozenset(visible_ids)

    props = get_instant_edit_props()
    selected_id = props.export_destination or NO_EXPORT_CONTEXT
    selected_index = next(
        (index for index, value in enumerate(collections)
         if str(_value(value, "context_id", "")) == selected_id),
        None,
    )
    if selected_index is None:
        if not collections:
            # export_destination's update callback (_export_destination_changed)
            # runs on every assignment regardless of whether the value actually
            # changes, and it writes several more properties itself. Without
            # this guard, every debounced run of this handler while no context
            # exists in the scene rewrote export_destination to the value it
            # already had - a property write with no actual state change
            # behind it, forcing a redraw of anything displaying it (this
            # add-on's own panel included) on every tick, unlike the "context
            # selected" case below, which already only writes when the value
            # genuinely changes.
            if selected_id != NO_EXPORT_CONTEXT:
                props.export_destination = NO_EXPORT_CONTEXT
            if props.variant_targets:
                props.variant_targets.clear()
            if props.variant_targets_context_id:
                props.variant_targets_context_id = ""
            return
        # An empty selector is also a deliberate choice while contexts are
        # visible. Only recover it after the handler observed no visible
        # contexts, such as when a collection is created or un-hidden. If the
        # first observation finds exactly one visible context, it is safe to
        # treat it as the same recovery case.
        if visible and (
            previous_visible_context_ids == frozenset()
            or (previous_visible_context_ids is None and len(visible) == 1)
        ):
            props.export_destination = str(_value(visible[0], "context_id", ""))
        elif selected_id != NO_EXPORT_CONTEXT:
            props.export_destination = NO_EXPORT_CONTEXT
            if props.variant_targets:
                props.variant_targets.clear()
            if props.variant_targets_context_id:
                props.variant_targets_context_id = ""
        return
    if len(collections) < 2 or collections[selected_index] in visible_set:
        return

    target_id = NO_EXPORT_CONTEXT
    preferred_objects = []
    active = getattr(view_layer.objects, "active", None)
    if active is not None:
        preferred_objects.append(active)
    preferred_objects.extend(
        obj for obj in getattr(bpy.context, "selected_objects", ())
        if obj is not active
    )
    for obj in preferred_objects:
        context_id = context_id_for_object(obj)
        if context_id in visible_ids:
            target_id = context_id
            break
    else:
        for offset in range(1, len(collections) + 1):
            candidate = collections[(selected_index + offset) % len(collections)]
            candidate_id = str(_value(candidate, "context_id", ""))
            if candidate_id in visible_ids:
                target_id = candidate_id
                break

    if props.export_destination != target_id:
        # Enum assignment deliberately reuses _export_destination_changed so
        # cached Penumbra target data is cleared and rebuilt for the new Context.
        props.export_destination = target_id


def _run_visibility_check():
    global _visibility_check_pending
    _visibility_check_pending = False
    try:
        _switch_hidden_export_context()
    except (AttributeError, ReferenceError, RuntimeError):
        pass
    return None


@persistent
def _context_visibility_changed(_scene, _depsgraph) -> None:
    """Debounce the visibility check against every depsgraph update.

    This handler runs on every depsgraph update, not just visibility
    toggles - continuous viewport interaction (dragging, painting,
    sculpting) fires it dozens of times per second. Rescheduling the timer
    on each call, instead of only scheduling once while one is already
    pending, collapses a whole burst of updates into a single check that
    runs shortly after activity settles, rather than running repeatedly
    throughout the interaction.
    """
    global _visibility_check_pending
    if bpy.app.timers.is_registered(_run_visibility_check):
        bpy.app.timers.unregister(_run_visibility_check)
    _visibility_check_pending = True
    bpy.app.timers.register(_run_visibility_check, first_interval=0.05)


def register() -> None:
    global _last_visible_context_ids
    from .ops import poll_material_coverage_results, reset_material_coverage_state
    from .cache import restore_cache_configuration

    _last_visible_context_ids = None
    reset_material_coverage_state()
    set_addon_properties()
    restore_cache_configuration()

    port = 42424
    try:
        from ..preferences import get_prefs
        prefs = get_prefs()
        port = prefs.instant_edit_blender_port
    except Exception as error:
        from .diagnostics import record_failure
        record_failure(
            component="blender_addon",
            operation="addon_startup",
            stage="preferences",
            code="addon_preferences_unavailable",
            cause="Blender could not read the XIV Instant Edit add-on preferences.",
            remedy="Verify the Blender add-on installation and restart Blender.",
            endpoint="/startup",
            exception=error,
        )
        print(f"XIV Instant Edit: could not read add-on preferences: {error}")

    if not start_server(port):
        error = get_server_error() or "the port may already be in use"
        message = f"{LISTENER_UNAVAILABLE} on port {port}: {error}"
        try:
            get_instant_edit_props().last_status = message
        except (AttributeError, RuntimeError):
            # Blender's startup context has no scene yet; the connection panel still reports it.
            pass
        print(message)
    bpy.app.timers.register(poll_import_queue, first_interval=1.0, persistent=True)
    # Retries only after start_server failed, e.g. while another Blender holds the port.
    bpy.app.timers.register(poll_listener, first_interval=LISTENER_RETRY_SECONDS, persistent=True)
    bpy.app.timers.register(
        poll_material_coverage_results,
        first_interval=0.25,
        persistent=True,
    )
    if _prepare_for_scene_load not in bpy.app.handlers.load_pre:
        bpy.app.handlers.load_pre.append(_prepare_for_scene_load)
    if _recover_after_scene_load not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_recover_after_scene_load)
    if _context_visibility_changed not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(_context_visibility_changed)
    schedule_recovery()
    schedule_revocations()


def unregister() -> None:
    global _visibility_check_pending, _last_visible_context_ids
    from .ops import poll_material_coverage_results, reset_material_coverage_state

    if _context_visibility_changed in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(_context_visibility_changed)
    if _prepare_for_scene_load in bpy.app.handlers.load_pre:
        bpy.app.handlers.load_pre.remove(_prepare_for_scene_load)
    if _recover_after_scene_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_recover_after_scene_load)
    cancel_recovery()
    cancel_revocations()
    stop_server()
    try:
        bpy.app.timers.unregister(poll_import_queue)
    except Exception:
        pass
    try:
        bpy.app.timers.unregister(poll_listener)
    except Exception:
        pass
    try:
        bpy.app.timers.unregister(poll_material_coverage_results)
    except Exception:
        pass
    try:
        bpy.app.timers.unregister(_run_visibility_check)
    except Exception:
        pass
    _visibility_check_pending = False
    _last_visible_context_ids = None
    reset_material_coverage_state()
    try:
        remove_addon_properties()
    except (AttributeError, RuntimeError):
        pass
